function RES = multiseed_R2P3(nRuns, opts)
% MULTISEED_R2P3  Round-2, Point 3: multi-seed statistical comparison of NSGA-III and MOWOA
% (with the homogeneous baselines and the two Q-learning baselines), including Pareto-front
% quality indicators (hypervolume, IGD+, additive epsilon), confidence intervals and
% significance tests.
%
% USAGE
%   RES = multiseed_R2P3;            % 20 independent runs (default), then the statistical analysis
%   RES = multiseed_R2P3(20);        % same
%   RES = multiseed_R2P3('analyze'); % analysis only, using the runs that are already finished
%
% DESIGN
%   * Run r uses its own optimization-data seed, initial population, NSGA-III and MOWOA operator
%     seeds and Q-learning seeds: base seed + 17*(r-1). Run 1 therefore uses exactly the seeds of
%     the published study (41001, 61001, 62001, 63001, 64001/64002) and must reproduce the
%     published NSGA-III / MOWOA / Q-learning beam vectors (checked automatically).
%   * Within a run all methods use the same optimization data, the same initial population, the
%     same population size and the same number of evaluations (70*101 = 7070).
%   * All final solutions are evaluated on the SAME 200-snapshot evaluation data (seed 51001)
%     that is used in the paper, so the 11 deterministic configurations (nine homogeneous beam
%     counts and two load-aware heuristics) are identical in every run.
%   * Pareto-front indicators (hypervolume, IGD+, additive epsilon) are computed per run from the
%     historical archives of the two optimizers, in the objective space of the optimization data
%     (the objectives the optimizers actually optimize), after min-max normalization with the
%     bounds of the union of both archives of the same run.
%   * Statistics (implemented here, no toolbox needed): bootstrap confidence intervals, paired
%     Wilcoxon signed-rank tests with Holm correction, Friedman test, Vargha-Delaney A12.
%
% CHECKPOINTS
%   Each finished run is saved to multiseed_R2P3_outputs/runs/run_XXX.mat. If MATLAB stops, run the
%   same command again: finished runs are skipped and the work continues with the next run.
%   (Use a different output folder, or delete the folder, if you change any setting.)
%
% OUTPUT (folder multiseed_R2P3_outputs)
%   console_log.txt, runs/run_XXX.mat, Table_R2P3_*.doc, Fig_R2P3_*.png, MULTISEED_R2P3_RESULTS.mat
% -------------------------------------------------------------------------
if nargin < 1 || isempty(nRuns), nRuns = 20; end
if nargin < 2, opts = struct(); end
analyzeOnly = ischar(nRuns) && strcmpi(nRuns, 'analyze');

outDir = fullfile(pwd, 'multiseed_R2P3_outputs');
if isfield(opts, 'outDir'), outDir = opts.outDir; end
runsDir = fullfile(outDir, 'runs');
if ~exist(runsDir, 'dir'), mkdir(runsDir); end
diary(fullfile(outDir, 'console_log.txt'));
diaryGuard = onCleanup(@() diary('off'));
sessionTimer = tic;
fprintf('\n=== multiseed_R2P3 started %s ===\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));

if analyzeOnly
    RES = analyze_all(outDir, sessionTimer);
    return;
end

% ------------------------------ settings -----------------------------------
P = make_params(opts);
R = rl_settings(P, opts);
sig = sprintf('maxGen=%d|NsnapOpt=%d|NsnapEval=%d|rlSteps=%d|pop=%d', P.maxGen, P.NsnapOpt, P.NsnapEval, R.nSteps, P.popSize);
fullSize = (P.maxGen == 100 && P.NsnapOpt == 25 && P.NsnapEval == 200 && R.nSteps == P.popSize*(P.maxGen+1));
fprintf('Settings: %s\n', sig);
fprintf('Runs requested: %d (each run: NSGA-III + MOWOA + two Q-learning variants)\n', nRuns);
fprintf('Seeds of run r: optimization data %d+17(r-1), initial population %d+17(r-1), NSGA-III %d+17(r-1), MOWOA %d+17(r-1), Q-learning %d+17(r-1) (+1 for variant B)\n', ...
    P.seedOptData0, P.seedInitialPopulation0, P.seedNSGAOperators0, P.seedMOWOAOperators0, R.seedBase);
fprintf('Evaluation data seed (common to all runs and methods): %d\n\n', P.seedEvalData);

% ------------------------------ common deterministic references -----------
fprintf('Generating the common evaluation data (%d snapshots)...\n', P.NsnapEval);
DATAeval = generate_mc_data(P, P.NsnapEval, P.seedEvalData);
ref.names = cell(1, 11); ref.K = cell(1, 11); ref.metrics = cell(1, 11);
for kk = 1:P.numCandidates
    ref.names{kk} = sprintf('Fixed %d', P.beamCandidates(kk));
    ref.K{kk} = P.beamCandidates(kk) * ones(1, P.numPairs);
end
ref.names{10} = 'Load-prop heuristic'; ref.K{10} = heuristic_beam_vector(P, 'proportional');
ref.names{11} = 'Inverse-load heuristic'; ref.K{11} = heuristic_beam_vector(P, 'inverse');
for kk = 1:11
    ref.metrics{kk} = evaluate_solution(ref.K{kk}, P, DATAeval, false);
end
setupFile = fullfile(outDir, 'setup.mat');
if exist(setupFile, 'file') == 2
    S0 = load(setupFile);
    if ~strcmp(S0.sig, sig)
        error(['The output folder already contains runs made with other settings (%s). ' ...
               'Delete the folder or choose another one (opts.outDir).'], S0.sig);
    end
else
    save(setupFile, 'P', 'R', 'ref', 'sig', '-v7');
end

% ------------------------------ run loop -----------------------------------
doneTimes = [];
for r = 1:nRuns
    runFile = fullfile(runsDir, sprintf('run_%03d.mat', r));
    if exist(runFile, 'file') == 2
        S = load(runFile, 'RUN');
        if ~strcmp(S.RUN.signature, sig)
            error('Run file %s was made with other settings (%s).', runFile, S.RUN.signature);
        end
        doneTimes(end+1) = S.RUN.time.total; %#ok<AGROW>
        fprintf('Run %d/%d already finished (%s) - skipped.\n', r, nRuns, fmt_dur(S.RUN.time.total));
        continue;
    end
    fprintf('\n==================== RUN %d / %d ====================\n', r, nRuns);
    tRun = tic;
    RUN = run_single(r, P, R, DATAeval, ref, sig, fullSize);
    RUN.time.total = toc(tRun);
    save(runFile, 'RUN', '-v7');
    doneTimes(end+1) = RUN.time.total; %#ok<AGROW>
    remaining = 0;
    for r2 = r+1:nRuns
        if exist(fullfile(runsDir, sprintf('run_%03d.mat', r2)), 'file') ~= 2, remaining = remaining + 1; end
    end
    fprintf('Run %d/%d finished in %s | this session so far %s | average per run %s | estimated remaining %s\n', ...
        r, nRuns, fmt_dur(RUN.time.total), fmt_dur(toc(sessionTimer)), fmt_dur(mean(doneTimes)), fmt_dur(mean(doneTimes)*remaining));
end

fprintf('\nAll %d runs are finished. Starting the statistical analysis...\n', nRuns);
RES = analyze_all(outDir, sessionTimer);
end

% =========================================================================
% Settings
% =========================================================================
function P = make_params(opts)
P = nominal_params();
P.seedOptData0 = 41001;
P.seedInitialPopulation0 = 61001;
P.seedNSGAOperators0 = 62001;
P.seedMOWOAOperators0 = 63001;
P.numObjectives = 5;
P.numDecisionVars = P.numPairs;
P.refDivisions = 4;
P.refPoints = generate_reference_points(P.numObjectives, P.refDivisions);
P.popSize = size(P.refPoints, 1);        % 70
P.maxGen = 100;
P.pMutation = min(0.20, 2/P.numDecisionVars);
P.pCrossover = 0.90;
P.workingArchiveSize = P.popSize;
P.mowoaSpiralB = 1.0;
if isfield(opts, 'maxGen'), P.maxGen = opts.maxGen; end
if isfield(opts, 'NsnapOpt'), P.NsnapOpt = opts.NsnapOpt; end
if isfield(opts, 'NsnapEval'), P.NsnapEval = opts.NsnapEval; end
end

function R = rl_settings(P, opts)
R.nSteps = P.popSize * (P.maxGen + 1);   % same evaluation budget as the metaheuristics
R.gamma = 0.5;
R.alphaMin = 0.02;
R.alphaExp = 0.6;
R.epsStart = 1.0;
R.epsEnd = 0.02;
R.epsDecayFrac = 0.70;
R.seedBase = 64001;
R.verbose = false;
if isfield(opts, 'rlSteps'), R.nSteps = opts.rlSteps; end
end

function s = fmt_dur(sec)
sec = round(sec);
h = floor(sec/3600); m = floor((sec - 3600*h)/60); s2 = sec - 3600*h - 60*m;
if h > 0
    s = sprintf('%d h %02d min %02d s', h, m, s2);
elseif m > 0
    s = sprintf('%d min %02d s', m, s2);
else
    s = sprintf('%d s', s2);
end
end

% =========================================================================
% One independent run
% =========================================================================
function RUN = run_single(r, P, R, DATAeval, ref, sig, fullSize)
stride = 17;
off = stride * (r - 1);
Pr = P;
Pr.seedOptData = P.seedOptData0 + off;
Pr.seedInitialPopulation = P.seedInitialPopulation0 + off;
Pr.seedNSGAOperators = P.seedNSGAOperators0 + off;
Pr.seedMOWOAOperators = P.seedMOWOAOperators0 + off;
Rr = R;
Rr.seedBase = R.seedBase + off;
assert(Pr.seedOptData ~= P.seedEvalData, 'Optimization and evaluation data seeds must differ.');

RUN = struct();
RUN.r = r;
RUN.signature = sig;
RUN.seeds = struct('optData', Pr.seedOptData, 'initialPop', Pr.seedInitialPopulation, ...
    'nsga', Pr.seedNSGAOperators, 'mowoa', Pr.seedMOWOAOperators, 'rlA', Rr.seedBase, 'rlB', Rr.seedBase + 1, ...
    'evalData', P.seedEvalData);

fprintf('Seeds: opt data %d, init pop %d, NSGA-III %d, MOWOA %d, Q-learning %d/%d\n', ...
    RUN.seeds.optData, RUN.seeds.initialPop, RUN.seeds.nsga, RUN.seeds.mowoa, RUN.seeds.rlA, RUN.seeds.rlB);
DATAopt = generate_mc_data(Pr, Pr.NsnapOpt, Pr.seedOptData);
initialPop = generate_initial_population(Pr, Pr.seedInitialPopulation);

% ---- NSGA-III ----
fprintf('Running NSGA-III (run %d)...\n', r);
t0 = tic; NSGA = run_nsga3(Pr, DATAopt, initialPop); RUN.time.nsga = toc(t0);
fN = compute_fom_equal_weights(NSGA.historicalArchive.metrics);
[RUN.optFoM.nsga, iN] = max(fN);
K_N = Pr.beamCandidates(NSGA.historicalArchive.population(iN, :));

% ---- MOWOA ----
fprintf('Running MOWOA (run %d)...\n', r);
t0 = tic; MOWOA = run_mowoa(Pr, DATAopt, initialPop); RUN.time.mowoa = toc(t0);
fM = compute_fom_equal_weights(MOWOA.historicalArchive.metrics);
[RUN.optFoM.mowoa, iM] = max(fM);
K_M = Pr.beamCandidates(MOWOA.historicalArchive.population(iM, :));

% ---- Q-learning baselines ----
M5hom = zeros(Pr.numCandidates, 5);
for kk = 1:Pr.numCandidates
    m = evaluate_solution(Pr.beamCandidates(kk)*ones(1, Pr.numPairs), Pr, DATAopt, false);
    M5hom(kk, :) = metric5(m);
end
bounds.lo = min(M5hom, [], 1); bounds.hi = max(M5hom, [], 1);
fprintf('Training Q-learning variant A (local reward) and B (shared reward)...\n');
t0 = tic; LA = train_q_learning(Pr, Rr, DATAopt, 'local', bounds, Rr.seedBase); RUN.time.rlA = toc(t0);
t0 = tic; LB = train_q_learning(Pr, Rr, DATAopt, 'shared', bounds, Rr.seedBase + 1); RUN.time.rlB = toc(t0);

% ---- evaluation on the common evaluation data ----
RUN.K.nsga = K_N; RUN.K.mowoa = K_M; RUN.K.rlA = LA.K; RUN.K.rlB = LB.K;
RUN.M.nsga = evaluate_solution(K_N, Pr, DATAeval, false);
RUN.M.mowoa = evaluate_solution(K_M, Pr, DATAeval, false);
RUN.M.rlA = evaluate_solution(LA.K, Pr, DATAeval, false);
RUN.M.rlB = evaluate_solution(LB.K, Pr, DATAeval, false);

% ---- pooled FoM over 15 candidates (9 fixed, 2 heuristics, NSGA-III, MOWOA, RL-A, RL-B) ----
allStructs = [ref.metrics, {RUN.M.nsga, RUN.M.mowoa, RUN.M.rlA, RUN.M.rlB}];
[f15, ord15] = pool_fom(allStructs);
rk15 = zeros(15, 1); rk15(ord15) = 1:15;
[f13, ord13] = pool_fom(allStructs(1:13));
rk13 = zeros(13, 1); rk13(ord13) = 1:13;
RUN.pool15.FoM = f15(:); RUN.pool15.rank = rk15;
RUN.pool13.FoM = f13(:); RUN.pool13.rank = rk13;

% ---- Pareto-front quality indicators (optimization-data objective space) ----
RUN.ind = pareto_indicators(NSGA.historicalArchive.objectives, MOWOA.historicalArchive.objectives, r);

% ---- archives and histories (kept for the reproducibility package) ----
RUN.archive.nsga.population = uint8(NSGA.historicalArchive.population);
RUN.archive.nsga.objectives = NSGA.historicalArchive.objectives;
RUN.archive.nsga.metrics = NSGA.historicalArchive.metrics;
RUN.archive.mowoa.population = uint8(MOWOA.historicalArchive.population);
RUN.archive.mowoa.objectives = MOWOA.historicalArchive.objectives;
RUN.archive.mowoa.metrics = MOWOA.historicalArchive.metrics;
RUN.history.nsga = NSGA.history;
RUN.history.mowoa = MOWOA.history;
RUN.rlTrace.A = single(LA.trace); RUN.rlTrace.B = single(LB.trace);

% ---- run summary ----
fprintf('\nRun %d summary (evaluation data):\n', r);
fprintf('  NSGA-III : K mean %.2f | Tput %.4f | P5SINR %.3f | JFI %.4f | OH %.3f | Int %.3f | pooled-FoM rank %d/15\n', ...
    mean(K_N), RUN.M.nsga.AvgEffTput_Mbps, RUN.M.nsga.P5SINR_dB, RUN.M.nsga.JFI, RUN.M.nsga.AvgOverhead_percent, RUN.M.nsga.AvgInterference_dBm, rk15(12));
fprintf('  MOWOA    : K mean %.2f | Tput %.4f | P5SINR %.3f | JFI %.4f | OH %.3f | Int %.3f | pooled-FoM rank %d/15\n', ...
    mean(K_M), RUN.M.mowoa.AvgEffTput_Mbps, RUN.M.mowoa.P5SINR_dB, RUN.M.mowoa.JFI, RUN.M.mowoa.AvgOverhead_percent, RUN.M.mowoa.AvgInterference_dBm, rk15(13));
fprintf('  RL-A / RL-B pooled-FoM rank: %d / %d (of 15) | K mean %.2f / %.2f\n', rk15(14), rk15(15), mean(LA.K), mean(LB.K));
fprintf('  Indicators NSGA-III vs MOWOA: HV %.4f vs %.4f | IGD+ %.4f vs %.4f | eps+ %.4f vs %.4f | archive sizes %d vs %d\n', ...
    RUN.ind.HV(1), RUN.ind.HV(2), RUN.ind.IGDplus(1), RUN.ind.IGDplus(2), RUN.ind.EPSplus(1), RUN.ind.EPSplus(2), RUN.ind.size(1), RUN.ind.size(2));
fprintf('  Time: NSGA-III %s, MOWOA %s, Q-learning A %s, B %s\n', fmt_dur(RUN.time.nsga), fmt_dur(RUN.time.mowoa), fmt_dur(RUN.time.rlA), fmt_dur(RUN.time.rlB));

% ---- reproduction check of run 1 against the published study ----
if r == 1 && fullSize
    K_NSGA_pub  = [8 15 20 8 10 15 8 24 15 15 8 10 10 24 8 8 6 24 15 8 8];
    K_MOWOA_pub = [6 10 10 8 10 15 10 15 10 15 8 8 8 24 6 4 4 20 10 10 6];
    K_RLA_pub = [2 2 2 3 2 2 2 3 3 2 2 2 2 2 2 2 2 2 3 2 2];
    K_RLB_pub = [8 15 20 6 20 15 6 15 6 20 8 4 10 10 6 4 6 24 20 10 6];
    ok = isequal(K_N, K_NSGA_pub) && isequal(K_M, K_MOWOA_pub);
    okRL = isequal(LA.K, K_RLA_pub) && isequal(LB.K, K_RLB_pub);
    if ok
        fprintf('Reproduction check (run 1): NSGA-III and MOWOA beam vectors are identical to the published ones.\n');
    else
        warning('Reproduction check FAILED: run-1 NSGA-III/MOWOA beam vectors differ from the published ones (different MATLAB version or random-number generator?).');
    end
    if okRL
        fprintf('Reproduction check (run 1): Q-learning beam vectors are identical to the earlier Point-1 results.\n');
    else
        warning('Reproduction note: run-1 Q-learning beam vectors differ from the earlier Point-1 results.');
    end
    RUN.reproduction = struct('optimizersIdentical', ok, 'rlIdentical', okRL);
end
end

% =========================================================================
% Pareto-front quality indicators
% =========================================================================
function IND = pareto_indicators(objN, objM, r)
% All objectives are minimization objectives. Normalization uses the ideal and nadir points of the
% union of the two archives of the same run, so that every archive point lies in [0,1]^5.
U = [objN; objM];
ideal = min(U, [], 1); nadir = max(U, [], 1);
rng_ = nadir - ideal; rng_(rng_ < 1e-12) = 1;
AN = bsxfun(@rdivide, bsxfun(@minus, objN, ideal), rng_);
AM = bsxfun(@rdivide, bsxfun(@minus, objM, ideal), rng_);
UN = [AN; AM];
% reference set Z: unique non-dominated points of the union
UN = unique(UN, 'rows');
keep = true(size(UN, 1), 1);
for i = 1:size(UN, 1)
    allLE = all(bsxfun(@le, UN, UN(i, :)), 2);
    anyLT = any(bsxfun(@lt, UN, UN(i, :)), 2);
    if any(allLE & anyLT), keep(i) = false; end
end
Z = UN(keep, :);

IND.size = [size(AN, 1), size(AM, 1)];
IND.refSetSize = size(Z, 1);
% contribution of each algorithm to the reference set (points of Z present in its archive)
IND.contribution = [sum(ismember(Z, AN, 'rows')), sum(ismember(Z, AM, 'rows'))] / size(Z, 1);

% hypervolume (Monte Carlo, common random numbers for both archives), reference point 1.1
refPt = 1.1; nS = 300000;
rngState = rng; rng(900000 + r, 'twister');
S = refPt * rand(nS, size(AN, 2));
rng(rngState);
IND.HV = [mc_hypervolume(AN, S, refPt), mc_hypervolume(AM, S, refPt)];
IND.IGDplus = [igd_plus(AN, Z), igd_plus(AM, Z)];
IND.EPSplus = [eps_plus(AN, Z), eps_plus(AM, Z)];
end

function hv = mc_hypervolume(A, S, refPt)
% Monte Carlo hypervolume: fraction of uniform samples in [0,refPt]^d dominated by the set A.
A = A(all(A <= refPt, 2), :);
nS = size(S, 1); ndim = size(S, 2);
for j = 1:size(A, 1)
    dom = all(bsxfun(@ge, S, A(j, :)), 2);
    S = S(~dom, :);
    if isempty(S), break; end
end
hv = (nS - size(S, 1)) / nS * refPt^ndim;
end

function v = igd_plus(A, Z)
% mean over reference points z of the smallest modified distance to the approximation set A
d = zeros(size(Z, 1), 1);
for i = 1:size(Z, 1)
    diffs = max(bsxfun(@minus, A, Z(i, :)), 0);
    d(i) = sqrt(min(sum(diffs.^2, 2)));
end
v = mean(d);
end

function v = eps_plus(A, Z)
% additive epsilon indicator I_eps+(A, Z) = max_z min_a max_i (a_i - z_i)
e = zeros(size(Z, 1), 1);
for i = 1:size(Z, 1)
    e(i) = min(max(bsxfun(@minus, A, Z(i, :)), [], 2));
end
v = max(e);
end

% =========================================================================
% Analysis of all finished runs
% =========================================================================
function RES = analyze_all(outDir, sessionTimer)
runsDir = fullfile(outDir, 'runs');
files = dir(fullfile(runsDir, 'run_*.mat'));
n = numel(files);
if n == 0
    error('No finished runs found in %s', runsDir);
end
setup = load(fullfile(outDir, 'setup.mat'));
P = setup.P; ref = setup.ref;
fprintf('\n=================== STATISTICAL ANALYSIS OVER %d RUNS ===================\n', n);

mf = {'AvgEffTput_Mbps', 'P5SINR_dB', 'JFI', 'AvgOverhead_percent', 'AvgInterference_dBm', 'P5Tput_Mbps', 'MedianTput_Mbps', 'Coverage_pct'};
mlabel = {'Avg. effective throughput (Mbps/user)', '5%-tile SINR (dB)', 'Jain fairness index', 'Avg. overhead (%)', ...
          'Avg. interference (dBm)', '5%-tile throughput (Mbps/user)', 'Median throughput (Mbps/user)', 'Coverage SINR>3 dB (%)'};
mbenefit = [1 1 1 0 0 1 1 1];
mdec = [4 3 4 3 3 4 4 3];
meth = {'nsga', 'mowoa', 'rlB', 'rlA'};
mname = {'NSGA-III', 'MOWOA', 'RL-B', 'RL-A'};
X = struct(); for q = 1:numel(meth), X.(meth{q}) = zeros(n, numel(mf)); end
pool15 = zeros(n, 15); rank15 = zeros(n, 15); pool13 = zeros(n, 13); rank13 = zeros(n, 13);
ind = struct('HV', zeros(n, 2), 'IGDplus', zeros(n, 2), 'EPSplus', zeros(n, 2), 'size', zeros(n, 2), 'contribution', zeros(n, 2), 'refSetSize', zeros(n, 1));
Kmean = zeros(n, 4); tmin = zeros(n, 1); seedOpt = zeros(n, 1); rlRank = zeros(n, 2);
repro = [];
for i = 1:n
    S = load(fullfile(runsDir, files(i).name)); RUN = S.RUN;
    for q = 1:numel(meth)
        for j = 1:numel(mf), X.(meth{q})(i, j) = RUN.M.(meth{q}).(mf{j}); end
    end
    pool15(i, :) = RUN.pool15.FoM'; rank15(i, :) = RUN.pool15.rank';
    pool13(i, :) = RUN.pool13.FoM'; rank13(i, :) = RUN.pool13.rank';
    ind.HV(i, :) = RUN.ind.HV; ind.IGDplus(i, :) = RUN.ind.IGDplus; ind.EPSplus(i, :) = RUN.ind.EPSplus;
    ind.size(i, :) = RUN.ind.size; ind.contribution(i, :) = RUN.ind.contribution; ind.refSetSize(i) = RUN.ind.refSetSize;
    Kmean(i, :) = [mean(RUN.K.nsga), mean(RUN.K.mowoa), mean(RUN.K.rlB), mean(RUN.K.rlA)];
    tmin(i) = RUN.time.total / 60; seedOpt(i) = RUN.seeds.optData;
    if isfield(RUN, 'reproduction'), repro = RUN.reproduction; end
end
Xref = zeros(11, numel(mf));
for k = 1:11, for j = 1:numel(mf), Xref(k, j) = ref.metrics{k}.(mf{j}); end, end
totalCompute = sum(tmin) * 60;

rngState = rng; rng(20261010, 'twister');
B = 10000;

% ---------------- Table 1: mean [95% CI] ----------------
refIdx = [5 6 7]; refNames = {'Fixed 8', 'Fixed 10', 'Fixed 15'};
hdr1 = [{'Measure'}, mname, refNames];
rows1 = cell(numel(mf) + 1, numel(hdr1));
for j = 1:numel(mf)
    rows1{j, 1} = mlabel{j};
    for q = 1:numel(meth)
        x = X.(meth{q})(:, j);
        [lo, hi] = boot_ci_mean(x, B);
        rows1{j, 1+q} = sprintf('%.*f [%.*f, %.*f]', mdec(j), mean(x), mdec(j), lo, mdec(j), hi);
    end
    for k = 1:3, rows1{j, 5+k} = sprintf('%.*f', mdec(j), Xref(refIdx(k), j)); end
end
rows1{end, 1} = 'Pooled FoM (15 candidates)';
fomIdx = [12 13 15 14]; refPoolIdx = [5 6 7];
for q = 1:4
    x = pool15(:, fomIdx(q)); [lo, hi] = boot_ci_mean(x, B);
    rows1{end, 1+q} = sprintf('%.4f [%.4f, %.4f]', mean(x), lo, hi);
end
for k = 1:3
    x = pool15(:, refPoolIdx(k)); [lo, hi] = boot_ci_mean(x, B);
    rows1{end, 5+k} = sprintf('%.4f [%.4f, %.4f]', mean(x), lo, hi);
end

% ---------------- Table 2: median (IQR) and SD ----------------
hdr2 = [{'Measure'}, mname];
rows2 = cell(numel(mf) + 1, numel(hdr2));
for j = 1:numel(mf)
    rows2{j, 1} = mlabel{j};
    for q = 1:numel(meth)
        x = X.(meth{q})(:, j);
        rows2{j, 1+q} = sprintf('%.*f (%.*f-%.*f); SD %.*f', mdec(j), median(x), mdec(j), quant7(x, 0.25), mdec(j), quant7(x, 0.75), mdec(j), std(x));
    end
end
rows2{end, 1} = 'Pooled FoM (15 candidates)';
for q = 1:4
    x = pool15(:, fomIdx(q));
    rows2{end, 1+q} = sprintf('%.4f (%.4f-%.4f); SD %.4f', median(x), quant7(x, 0.25), quant7(x, 0.75), std(x));
end

% ---------------- Table 3: NSGA-III versus MOWOA (paired) ----------------
hdr3 = {'Measure', 'NSGA-III mean &plusmn; SD', 'MOWOA mean &plusmn; SD', 'Mean difference [95% CI]', 'Median difference', ...
        'Wilcoxon p', 'Holm p', 'A12 (NSGA-III better)', 'Runs NSGA-III better'};
meas3 = [1:8, 0];   % 0 = pooled FoM
rows3 = cell(numel(meas3), numel(hdr3)); p3 = zeros(numel(meas3), 1);
for t = 1:numel(meas3)
    j = meas3(t);
    if j > 0
        x = X.nsga(:, j); y = X.mowoa(:, j); lab = mlabel{j}; dec = mdec(j); ben = mbenefit(j);
    else
        x = pool15(:, 12); y = pool15(:, 13); lab = 'Pooled FoM (15 candidates)'; dec = 4; ben = 1;
    end
    d = x - y; [lo, hi] = boot_ci_mean(d, B);
    [p, ~] = signrank_p(d); p3(t) = p;
    if ben, a = a12(x, y); win = sum(d > 0); else, a = a12(y, x); win = sum(d < 0); end
    rows3(t, :) = {lab, sprintf('%.*f &plusmn; %.*f', dec, mean(x), dec, std(x)), sprintf('%.*f &plusmn; %.*f', dec, mean(y), dec, std(y)), ...
        sprintf('%+.*f [%+.*f, %+.*f]', dec, mean(d), dec, lo, dec, hi), sprintf('%+.*f', dec, median(d)), ...
        fmt_p(p), '', sprintf('%.3f', a), sprintf('%d / %d', win, n)};
end
h3 = holm_adjust(p3);
for t = 1:numel(meas3), rows3{t, 7} = fmt_p(h3(t)); end

% ---------------- Table 4: Pareto-front indicators ----------------
hdr4 = {'Indicator', 'NSGA-III mean &plusmn; SD', 'MOWOA mean &plusmn; SD', 'Mean difference [95% CI]', 'Median difference', ...
        'Wilcoxon p', 'Holm p', 'A12 (NSGA-III better)', 'Runs NSGA-III better'};
indNames = {'Hypervolume (higher is better)', 'IGD+ (lower is better)', 'Additive epsilon (lower is better)'};
indData = {ind.HV, ind.IGDplus, ind.EPSplus}; indBen = [1 0 0];
rows4 = cell(3, numel(hdr4)); p4 = zeros(3, 1);
for t = 1:3
    x = indData{t}(:, 1); y = indData{t}(:, 2); d = x - y; [lo, hi] = boot_ci_mean(d, B);
    p4(t) = signrank_p(d);
    if indBen(t), a = a12(x, y); win = sum(d > 0); else, a = a12(y, x); win = sum(d < 0); end
    rows4(t, :) = {indNames{t}, sprintf('%.4f &plusmn; %.4f', mean(x), std(x)), sprintf('%.4f &plusmn; %.4f', mean(y), std(y)), ...
        sprintf('%+.4f [%+.4f, %+.4f]', mean(d), lo, hi), sprintf('%+.4f', median(d)), fmt_p(p4(t)), '', sprintf('%.3f', a), sprintf('%d / %d', win, n)};
end
h4 = holm_adjust(p4);
for t = 1:3, rows4{t, 7} = fmt_p(h4(t)); end
rows4(end+1, :) = {'Archive size (solutions)', sprintf('%.1f &plusmn; %.1f', mean(ind.size(:, 1)), std(ind.size(:, 1))), ...
    sprintf('%.1f &plusmn; %.1f', mean(ind.size(:, 2)), std(ind.size(:, 2))), '', '', '', '', '', ''};
rows4(end+1, :) = {'Share of the reference set (non-dominated union)', sprintf('%.3f &plusmn; %.3f', mean(ind.contribution(:, 1)), std(ind.contribution(:, 1))), ...
    sprintf('%.3f &plusmn; %.3f', mean(ind.contribution(:, 2)), std(ind.contribution(:, 2))), '', '', '', '', '', ''};

% ---------------- Table 5: against the deterministic references ----------------
hdr5 = {'Method', 'Reference', 'Measure', 'Reference value', 'Method median', 'Median difference', 'Wilcoxon p', 'Holm p (within method and reference)', 'Runs method better'};
rows5 = {};
mset = [1 2 3 4 5 0];
for mm = 1:2
    for k = 1:3
        pk = zeros(numel(mset), 1); blk = cell(numel(mset), 9);
        for t = 1:numel(mset)
            j = mset(t);
            if j > 0
                x = X.(meth{mm})(:, j); rv = Xref(refIdx(k), j); lab = mlabel{j}; dec = mdec(j); ben = mbenefit(j);
                d = x - rv;
                refShow = sprintf('%.*f', dec, rv);
            else
                x = pool15(:, fomIdx(mm)); y = pool15(:, refPoolIdx(k)); lab = 'Pooled FoM (15 candidates, paired by run)'; dec = 4; ben = 1;
                d = x - y; refShow = sprintf('%.4f (mean)', mean(y));
            end
            pk(t) = signrank_p(d);
            if ben, win = sum(d > 0); else, win = sum(d < 0); end
            blk(t, :) = {mname{mm}, refNames{k}, lab, refShow, sprintf('%.*f', dec, median(x)), sprintf('%+.*f', dec, median(d)), fmt_p(pk(t)), '', sprintf('%d / %d', win, n)};
        end
        hk = holm_adjust(pk);
        for t = 1:numel(mset), blk{t, 8} = fmt_p(hk(t)); end
        rows5 = [rows5; blk]; %#ok<AGROW>
    end
end

% ---------------- Table 6: Friedman test and pairwise comparisons ----------------
fnames = {'NSGA-III', 'MOWOA', 'RL-B', 'RL-A', 'Fixed 8', 'Fixed 10', 'Fixed 15'};
fcols = [12 13 15 14 5 6 7];
Fm = pool15(:, fcols);
[chi2, pF, W, meanRank] = friedman_test(Fm);
hdr6 = {'Method', 'Mean rank among these methods (1 = best)', 'Median pooled FoM', 'Difference to NSGA-III: median', 'Wilcoxon p vs NSGA-III', 'Holm p'};
rows6 = cell(numel(fnames), numel(hdr6)); pp = ones(numel(fnames), 1);
for t = 1:numel(fnames)
    if t > 1, pp(t) = signrank_p(Fm(:, t) - Fm(:, 1)); end
end
hp = holm_adjust(pp(2:end));
for t = 1:numel(fnames)
    if t == 1
        rows6(t, :) = {fnames{t}, sprintf('%.2f', meanRank(t)), sprintf('%.4f', median(Fm(:, t))), '-', '-', '-'};
    else
        rows6(t, :) = {fnames{t}, sprintf('%.2f', meanRank(t)), sprintf('%.4f', median(Fm(:, t))), sprintf('%+.4f', median(Fm(:, t) - Fm(:, 1))), fmt_p(pp(t)), fmt_p(hp(t-1))};
    end
end
rows6(end+1, :) = {sprintf('Friedman test: chi-square = %.3f, df = %d, p = %s, Kendall W = %.3f (n = %d runs)', chi2, numel(fnames)-1, fmt_p(pF), W, n), '', '', '', '', ''};

% ---------------- Table 7: rank distribution over the 15 candidates ----------------
cnames = [ref.names, {'NSGA-III', 'MOWOA', 'RL-A', 'RL-B'}];
hdr7 = {'Configuration', 'Mean rank (of 15)', 'Median rank', 'Runs ranked 1st', 'Runs ranked in top 3', 'Mean pooled FoM'};
[~, ordMean] = sort(mean(rank15, 1), 'ascend');
rows7 = cell(15, numel(hdr7));
for t = 1:15
    c = ordMean(t);
    rows7(t, :) = {cnames{c}, sprintf('%.2f', mean(rank15(:, c))), sprintf('%.1f', median(rank15(:, c))), sprintf('%d / %d', sum(rank15(:, c) == 1), n), ...
        sprintf('%d / %d', sum(rank15(:, c) <= 3), n), sprintf('%.4f', mean(pool15(:, c)))};
end

% ---------------- Table 8: per-run raw results ----------------
hdr8 = {'Run', 'Opt. data seed', 'Mean K NSGA-III', 'Mean K MOWOA', 'FoM NSGA-III', 'FoM MOWOA', 'FoM RL-B', 'FoM RL-A', 'Rank NSGA-III', 'Rank MOWOA', 'Rank RL-B', 'Rank RL-A', ...
        'HV NSGA-III', 'HV MOWOA', 'IGD+ NSGA-III', 'IGD+ MOWOA', 'Time (min)'};
rows8 = cell(n, numel(hdr8));
for i = 1:n
    rows8(i, :) = {i, seedOpt(i), rnd(Kmean(i, 1), 2), rnd(Kmean(i, 2), 2), rnd(pool15(i, 12), 4), rnd(pool15(i, 13), 4), rnd(pool15(i, 15), 4), rnd(pool15(i, 14), 4), ...
        rank15(i, 12), rank15(i, 13), rank15(i, 15), rank15(i, 14), rnd(ind.HV(i, 1), 4), rnd(ind.HV(i, 2), 4), rnd(ind.IGDplus(i, 1), 4), rnd(ind.IGDplus(i, 2), 4), rnd(tmin(i), 1)};
end

% ---------------- export ----------------
write_cell_word(hdr1, rows1, fullfile(outDir, 'Table_R2P3_1_Mean_CI.doc'), sprintf('Mean [95%% bootstrap CI] over %d independent runs', n));
write_cell_word(hdr2, rows2, fullfile(outDir, 'Table_R2P3_2_Median_IQR.doc'), sprintf('Median (IQR) and standard deviation over %d independent runs', n));
write_cell_word(hdr3, rows3, fullfile(outDir, 'Table_R2P3_3_NSGA3_vs_MOWOA.doc'), sprintf('NSGA-III versus MOWOA, paired by run (n = %d); Holm correction over the nine measures', n));
write_cell_word(hdr4, rows4, fullfile(outDir, 'Table_R2P3_4_Pareto_Indicators.doc'), sprintf('Pareto-front quality indicators, NSGA-III versus MOWOA (n = %d); Holm correction over the three indicators', n));
write_cell_word(hdr5, rows5, fullfile(outDir, 'Table_R2P3_5_Versus_References.doc'), sprintf('Optimizers versus the deterministic homogeneous configurations (n = %d runs)', n));
write_cell_word(hdr6, rows6, fullfile(outDir, 'Table_R2P3_6_Friedman.doc'), sprintf('Friedman test of the pooled FoM over %d runs', n));
write_cell_word(hdr7, rows7, fullfile(outDir, 'Table_R2P3_7_Rank_Distribution.doc'), sprintf('Rank distribution among the 15 candidates over %d runs', n));
write_cell_word(hdr8, rows8, fullfile(outDir, 'Table_R2P3_8_Per_Run.doc'), 'Per-run results');

try
    plot_boxes(X, pool15, ind, mname, meth, fomIdx, outDir);
catch ME
    warning('Figure generation failed: %s', ME.message);
end
rng(rngState);

% ---------------- console summary ----------------
fprintf('\n---- NSGA-III versus MOWOA (paired, %d runs) ----\n', n); pc(hdr3, rows3);
fprintf('\n---- Pareto-front indicators ----\n'); pc(hdr4, rows4);
fprintf('\n---- Friedman test / pairwise ----\n'); pc(hdr6, rows6);
fprintf('\n---- Rank distribution (15 candidates) ----\n'); pc(hdr7, rows7);
fprintf('\nNSGA-III ranked 1st among the 15 candidates in %d of %d runs; MOWOA in %d; Fixed 10 in %d; Fixed 15 in %d; RL-B in %d.\n', ...
    sum(rank15(:, 12) == 1), n, sum(rank15(:, 13) == 1), sum(rank15(:, 6) == 1), sum(rank15(:, 7) == 1), sum(rank15(:, 15) == 1));

RES = struct();
RES.n = n; RES.X = X; RES.pool15 = pool15; RES.rank15 = rank15; RES.pool13 = pool13; RES.rank13 = rank13; RES.ind = ind;
RES.Kmean = Kmean; RES.timeMin = tmin; RES.seedOpt = seedOpt; RES.Xref = Xref; RES.refNames = ref.names; RES.reproduction = repro;
RES.tables = struct('t1', {{hdr1, rows1}}, 't2', {{hdr2, rows2}}, 't3', {{hdr3, rows3}}, 't4', {{hdr4, rows4}}, 't5', {{hdr5, rows5}}, 't6', {{hdr6, rows6}}, 't7', {{hdr7, rows7}}, 't8', {{hdr8, rows8}});
RES.friedman = struct('chi2', chi2, 'p', pF, 'W', W, 'meanRank', meanRank, 'names', {fnames});
save(fullfile(outDir, 'MULTISEED_R2P3_RESULTS.mat'), 'RES', '-v7');

fprintf('\nAll tables, figures, per-run files and the results file are in: %s\n', outDir);
fprintf('Compute time of all %d runs (sum of the per-run times): %s\n', n, fmt_dur(totalCompute));
fprintf('Wall-clock time of this MATLAB session: %s\n', fmt_dur(toc(sessionTimer)));
fprintf('=== TOTAL RUN TIME (all runs): %s ===\n', fmt_dur(totalCompute));
end

% =========================================================================
% Statistics (no toolbox required)
% =========================================================================
function [lo, hi] = boot_ci_mean(x, B)
x = x(:); n = numel(x);
if n < 2, lo = x(1); hi = x(1); return; end
idx = randi(n, B, n);
m = mean(reshape(x(idx), B, n), 2);
m = sort(m);
lo = m(max(1, round(0.025*B))); hi = m(min(B, round(0.975*B)));
end

function q = quant7(x, p)
x = sort(x(:)); n = numel(x);
if n == 1, q = x; return; end
h = (n - 1) * p + 1; lo = floor(h); hi = ceil(h);
q = x(lo) + (h - lo) * (x(hi) - x(lo));
end

function [p, info] = signrank_p(d)
% Two-sided Wilcoxon signed-rank test of H0: median(d) = 0. Zero differences are discarded.
% Exact p-value (dynamic programming) when there are no ties and n <= 30, otherwise the normal
% approximation with continuity and tie correction.
d = d(:); d = d(d ~= 0 & isfinite(d)); n = numel(d);
info = struct('n', n, 'W', NaN, 'exact', false);
if n == 0, p = 1; return; end
r = tiedrank_local(abs(d));
Wp = sum(r(d > 0));
info.W = Wp;
hasTies = numel(unique(abs(d))) < n;
if ~hasTies && n <= 30
    c = 1;
    for k = 1:n
        c = [c, zeros(1, k)] + [zeros(1, k), c]; %#ok<AGROW>
    end
    tot = 2^n; w = round(Wp);
    pl = sum(c(1:w+1)) / tot; pu = sum(c(w+1:end)) / tot;
    p = min(1, 2*min(pl, pu)); info.exact = true;
else
    mu = n*(n+1)/4;
    [~, ~, ic] = unique(abs(d)); t = accumarray(ic, 1);
    v = n*(n+1)*(2*n+1)/24 - sum(t.^3 - t)/48;
    if v <= 0, p = 1; return; end
    z = (abs(Wp - mu) - 0.5) / sqrt(v); z = max(z, 0);
    p = erfc(z / sqrt(2));
end
end

function a = a12(x, y)
% Vargha-Delaney A12: probability that a value of x exceeds a value of y (ties count one half).
x = x(:); y = y(:);
a = (sum(sum(bsxfun(@gt, x, y'))) + 0.5*sum(sum(bsxfun(@eq, x, y')))) / (numel(x)*numel(y));
end

function adj = holm_adjust(p)
p = p(:); m = numel(p);
[ps, ord] = sort(p, 'ascend');
a = zeros(m, 1);
for i = 1:m, a(i) = (m - i + 1) * ps(i); end
for i = 2:m, a(i) = max(a(i), a(i-1)); end
a = min(a, 1);
adj = zeros(m, 1); adj(ord) = a;
end

function [chi2, p, W, meanRank] = friedman_test(X)
% X: n blocks (runs) by k treatments; larger value = better = rank 1.
[n, k] = size(X);
Rk = zeros(n, k);
for i = 1:n, Rk(i, :) = tiedrank_local(-X(i, :)')'; end
Rj = sum(Rk, 1);
A = sum(Rk(:).^2); C = n*k*(k+1)^2/4;
if abs(A - C) < 1e-12
    chi2 = 0;
else
    chi2 = (k-1) * (sum(Rj.^2) - n*C) / (A - C);
end
p = 1 - gammainc(chi2/2, (k-1)/2);
p = max(min(p, 1), 0);
W = chi2 / (n*(k-1));
meanRank = Rj / n;
end

function pc(hdr, rows)
% console version of a table: HTML entities replaced by plain text
f = @(s) strrep(strrep(s, '&plusmn;', '+/-'), '&lt;', '<');
for i = 1:numel(hdr), hdr{i} = f(hdr{i}); end
for i = 1:numel(rows), if ischar(rows{i}), rows{i} = f(rows{i}); end, end
print_cells(hdr, rows);
end

function s = fmt_p(p)
if p < 0.0001
    s = '&lt;0.0001';
else
    s = sprintf('%.4f', p);
end
end

% =========================================================================
% Figure
% =========================================================================
function plot_boxes(X, pool15, ind, mname, meth, fomIdx, outDir)
f = figure('Visible', 'on', 'Color', 'w', 'Position', [100 100 1100 650]);
panels = {
    'Pooled FoM (15 candidates)', pool15(:, fomIdx), mname;
    'Hypervolume', ind.HV, {'NSGA-III', 'MOWOA'};
    'IGD+', ind.IGDplus, {'NSGA-III', 'MOWOA'};
    'Jain fairness index', [X.nsga(:, 3), X.mowoa(:, 3)], {'NSGA-III', 'MOWOA'};
    'Avg. throughput (Mbps/user)', [X.nsga(:, 1), X.mowoa(:, 1)], {'NSGA-III', 'MOWOA'};
    '5%-tile throughput (Mbps/user)', [X.nsga(:, 6), X.mowoa(:, 6)], {'NSGA-III', 'MOWOA'}};
for k = 1:size(panels, 1)
    subplot(2, 3, k); hold on;
    D = panels{k, 2};
    for c = 1:size(D, 2)
        draw_box(c, D(:, c));
    end
    set(gca, 'XTick', 1:size(D, 2), 'XTickLabel', panels{k, 3}, 'FontSize', 10);
    xlim([0.4, size(D, 2) + 0.6]); grid on; box on;
    title(panels{k, 1}, 'FontSize', 10);
end
set(f, 'PaperPositionMode', 'auto');
print(f, fullfile(outDir, 'Fig_R2P3_Boxplots.png'), '-dpng', '-r300');
close(f);
end

function draw_box(x0, v)
v = v(:);
q1 = quant7(v, 0.25); q2 = quant7(v, 0.5); q3 = quant7(v, 0.75);
iq = q3 - q1;
lw = min(v(v >= q1 - 1.5*iq)); uw = max(v(v <= q3 + 1.5*iq));
w = 0.28;
patch([x0-w x0+w x0+w x0-w], [q1 q1 q3 q3], [0.80 0.88 0.97], 'EdgeColor', [0.1 0.1 0.1]);
plot([x0-w x0+w], [q2 q2], 'k-', 'LineWidth', 1.8);
plot([x0 x0], [lw q1], 'k-'); plot([x0 x0], [q3 uw], 'k-');
plot([x0-w/2 x0+w/2], [lw lw], 'k-'); plot([x0-w/2 x0+w/2], [uw uw], 'k-');
jit = ((1:numel(v))' - (numel(v)+1)/2) / max(numel(v), 1) * 0.3;
plot(x0 + jit, v, '.', 'Color', [0.2 0.2 0.2], 'MarkerSize', 8);
out = v(v < lw | v > uw);
if ~isempty(out), plot(x0*ones(size(out)), out, 'ro', 'MarkerSize', 5); end
end

% =========================================================================
% Functions reused unchanged from nsga3_mowoa_beam_archive_R2P2.m and rl_baseline_R2P1.m
% (train_q_learning only gains the R.verbose switch; evaluate_solution has the optional 3rd output)
% =========================================================================

function L = train_q_learning(P, R, DATAopt, rewardMode, bounds, seed)
nQ = P.numPairs; nA = P.numCandidates;
rng(seed, 'twister');
Q = zeros(nQ, nA);
cnt = zeros(nQ, nA);
trace = zeros(R.nSteps, 1);
nDecay = max(1, R.epsDecayFrac * R.nSteps);
reportEvery = max(1, floor(R.nSteps/10));
for t = 1:R.nSteps
    eps_t = max(R.epsEnd, R.epsStart * (R.epsEnd/R.epsStart)^((t-1)/nDecay));
    a = zeros(1, nQ);
    for q = 1:nQ
        if rand < eps_t
            a(q) = randi(nA);
        else
            untried = find(cnt(q,:) == 0);
            if ~isempty(untried)
                a(q) = untried(randi(numel(untried)));
            else
                best = find(Q(q,:) >= max(Q(q,:)) - 1e-12);
                a(q) = best(randi(numel(best)));
            end
        end
    end
    Kvec = P.beamCandidates(a);
    [m, ~, secTput] = evaluate_solution(Kvec, P, DATAopt, false);
    rShared = shared_reward(m, bounds);
    trace(t) = rShared;
    if strcmp(rewardMode, 'local')
        r = secTput(:)';
    else
        r = rShared * ones(1, nQ);
    end
    for q = 1:nQ
        tried = cnt(q,:) > 0;
        if any(tried), mq = max(Q(q,tried)); else, mq = 0; end
        cnt(q,a(q)) = cnt(q,a(q)) + 1;
        alpha = max(R.alphaMin, 1/cnt(q,a(q))^R.alphaExp);
        Q(q,a(q)) = (1-alpha)*Q(q,a(q)) + alpha*(r(q) + R.gamma*mq);
    end
    if R.verbose && mod(t, reportEvery) == 0
        fprintf('  step %5d/%d  eps=%.3f  mean shared reward (last %d steps) = %.4f\n', ...
            t, R.nSteps, eps_t, min(t,reportEvery), mean(trace(max(1,t-reportEvery+1):t)));
    end
end
[~, idx] = max(Q, [], 2);
L.K = P.beamCandidates(idx(:)');
L.Q = Q; L.cnt = cnt; L.trace = trace;
end

function r = shared_reward(m, bounds)
x = metric5(m);
benefit = [true true true false false];
nb = zeros(1,5);
for j = 1:5
    d = bounds.hi(j) - bounds.lo(j);
    if d < 1e-12
        nb(j) = 1;
    elseif benefit(j)
        nb(j) = (x(j) - bounds.lo(j)) / d;
    else
        nb(j) = (bounds.hi(j) - x(j)) / d;
    end
end
r = mean(nb);
end

function x = metric5(m)
x = [m.AvgEffTput_Mbps, m.P5SINR_dB, m.JFI, m.AvgOverhead_percent, m.AvgInterference_dBm];
end

function [FoM, order, candMat] = pool_fom(structs)
n = numel(structs);
candMat = zeros(n, 8);
for k = 1:n
    m = structs{k};
    candMat(k,:) = [m.AvgEffTput_Mbps, m.P5SINR_dB, m.JFI, m.AvgOverhead_percent, ...
                    m.AvgInterference_dBm, m.Coverage_pct, m.AvgSINR_dB, m.P5Tput_Mbps];
end
FoM = compute_fom_equal_weights(candMat);
[~, order] = sort(FoM, 'descend');
end

function r = tiedrank_local(x)
[xs, ord] = sort(x);
r = zeros(size(x));
i = 1; n = numel(x);
while i <= n
    j = i;
    while j < n && xs(j+1) == xs(i), j = j + 1; end
    r(ord(i:j)) = (i + j)/2;
    i = j + 1;
end
end

function print_cells(hdr, rows)
fprintf('%s\n', strjoin(hdr, ' | '));
for i = 1:size(rows,1)
    parts = cell(1, size(rows,2));
    for c = 1:size(rows,2)
        v = rows{i,c};
        if ischar(v), parts{c} = v;
        elseif isnumeric(v) && isscalar(v)
            if v == round(v), parts{c} = sprintf('%d', v); else, parts{c} = sprintf('%.4f', v); end
        else, parts{c} = ''; end
    end
    fprintf('%s\n', strjoin(parts, ' | '));
end
end

function write_cell_word(hdr, rows, fname, tableTitle)
% Export a header cell array and a cell matrix of rows to a Word-readable .doc (HTML).
fid = fopen(fname, 'w');
if fid == -1
    warning('write_cell_word: cannot open %s', fname);
    return;
end
fprintf(fid, '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">\n');
fprintf(fid, '<head><meta charset="UTF-8"><title>%s</title>\n', tableTitle);
fprintf(fid, ['<style> body{font-family:Calibri,Arial,sans-serif;} table{border-collapse:collapse;width:100%%;} ' ...
    'th,td{border:1px solid #444444;padding:4px 6px;text-align:center;font-size:9pt;} ' ...
    'th{background-color:#D9E1F2;font-weight:bold;} h1{font-size:14pt;color:#1F4E78;} </style>\n']);
fprintf(fid, '</head><body>\n<h1>%s</h1>\n<table>\n<tr>', tableTitle);
for c = 1:numel(hdr)
    fprintf(fid, '<th>%s</th>', strrep(hdr{c}, '_', ' '));
end
fprintf(fid, '</tr>\n');
for r = 1:size(rows,1)
    fprintf(fid, '<tr>');
    for c = 1:size(rows,2)
        v = rows{r,c};
        if ischar(v)
            s = v;
        elseif isnumeric(v) && isscalar(v)
            if v == round(v), s = sprintf('%d', v); else, s = sprintf('%.4f', v); end
        else
            s = '';
        end
        fprintf(fid, '<td>%s</td>', s);
    end
    fprintf(fid, '</tr>\n');
end
fprintf(fid, '</table>\n</body></html>');
fclose(fid);
end

function y = rnd(x, d)
% Portable rounding to d decimals (also works in Octave).
y = round(x * 10^d) / 10^d;
end

function P = nominal_params()
P.numBS = 7;
P.numSec = 3;
P.numPairs = P.numBS * P.numSec;
P.UEsPerSec = 20;
P.useNonUniformLoad = true;
P.minUEsPerSec = 8;
P.maxUEsPerSec = 35;
P.loadJitterUE = 3;
P.sectorLoadProfile = [34 20 10, 14 28 12, 22 9 32, 11 24 18, 30 13 21, 16 27 8, 25 15 29];
P.NsnapOpt = 25;
P.NsnapEval = 200;
P.BW_Hz = 100e6;
P.f_c_Hz = 28e9;
P.Pt_dBm = 33;
P.NF_dB = 9;
P.antennaGain_dBi = 15;
P.frontBackLimit_dB = 30;
P.sectorSpan_deg = 120;
P.sectorRadius_m = 150;
P.mu = 3;
P.nSym_slot = 14;
P.nSym_SSB = 4;
P.T_ssb_period_ms = 20;
P.T_csi_period_ms = 5;
P.OH_cap = 0.50;
P.beamComplexityPenaltyMax = 0.10;
P.beamComplexityPenaltyPower = 1.0;
P.rho_active = 0.70;
P.rho_idle = 0.05;
P.Nref = 30;
P.eta_overlap = 0.50;
P.pCorrectAt8 = 0.90;
P.pCorrectSlope = 0.012;
P.pCorrectMin = 0.65;
P.pCorrectMax = 0.96;
P.sigmaSh_dB = 4;
P.coverageThreshold_dB = 3.0;
P.bsPos = [500 500; 800 500; 200 500; 650 760; 650 240; 350 760; 350 240];
P.beamCandidates = [2 3 4 6 8 10 15 20 24];
P.numCandidates = numel(P.beamCandidates);
P.seedEvalData = 51001;
P.Pt_W = 10^((P.Pt_dBm - 30)/10);
P.noise_dBm = -174 + 10*log10(P.BW_Hz) + P.NF_dB;
P.noise_W = 10^((P.noise_dBm - 30)/10);
P.T_slot_ms = 1/(2^P.mu);
P.Tsym_ms = P.T_slot_ms/P.nSym_slot;
P.T_SSB_ms = P.nSym_SSB*P.Tsym_ms;
P.OH_CSI_reference = P.Tsym_ms/P.T_csi_period_ms;
end

% =========================================================================
% Model functions copied unchanged from nsga3_mowoa_beam_archive_R2P2.m
% (evaluate_solution only gains the optional third output secTput)
% =========================================================================

function DATA = generate_mc_data(P, Nsnap, seedValue)
rng(seedValue, 'twister');
DATA = repmat(struct(), Nsnap, 1);

for snap = 1:Nsnap
    sectorLoad = generate_sector_loads(P);
    N = sum(sectorLoad);
    user = zeros(N, 5); % bs, sector, pair, x, y
    row = 0;

    % UEs are generated inside each active sector. In the corrected version,
    % sector loads are intentionally non-uniform to avoid artificial network
    % symmetry and to make sector-dependent beam selection meaningful.
    for bs = 1:P.numBS
        sx = P.bsPos(bs,1);
        sy = P.bsPos(bs,2);
        for sec = 1:P.numSec
            pair = (bs-1)*P.numSec + sec;
            Nu = sectorLoad(pair);
            az0 = (sec-1) * P.sectorSpan_deg;
            az1 = sec * P.sectorSpan_deg;
            r = sqrt(rand(Nu,1)) * P.sectorRadius_m;
            az = az0 + rand(Nu,1) * (az1 - az0);
            x = sx + r .* cosd(az);
            y = sy + r .* sind(az);
            idx = row + (1:Nu);
            user(idx,:) = [bs*ones(Nu,1), sec*ones(Nu,1), ...
                           pair*ones(Nu,1), x, y];
            row = row + Nu;
        end
    end

    x = user(:,4);
    y = user(:,5);

    localAng = zeros(N, P.numPairs);
    PL_dB = zeros(N, P.numPairs);

    for q = 1:P.numPairs
        [bsq, secq] = pair_to_bssec(q, P);
        xb = P.bsPos(bsq,1);
        yb = P.bsPos(bsq,2);
        th = atan2d(y - yb, x - xb);
        th(th < 0) = th(th < 0) + 360;

        % Corrected interference-angle model:
        % Do NOT clamp out-of-sector directions to 120-eps. Instead, keep
        % the wrapped local angle in [0,360). The antenna pattern then uses
        % wrap180(localAngle - beamCenter), which naturally gives low gain
        % for users outside the sector main angular region.
        thLocal = th - (secq-1)*P.sectorSpan_deg;
        thLocal = mod(thLocal, 360);
        localAng(:,q) = thLocal;

        d = hypot(x - xb, y - yb);
        PL_dB(:,q) = path_loss_uma_simple(d, P.f_c_Hz) + P.sigmaSh_dB*randn(N,1);
    end

    rhoSector = P.rho_idle + (P.rho_active - P.rho_idle) .* min(1, sectorLoad(:)/P.Nref);

    DATA(snap).snapshot = snap;
    DATA(snap).sectorLoad = sectorLoad(:);
    DATA(snap).rhoSector = rhoSector(:);
    DATA(snap).bsIdx = user(:,1);
    DATA(snap).secIdx = user(:,2);
    DATA(snap).pairIdx = user(:,3);
    DATA(snap).x_m = x;
    DATA(snap).y_m = y;
    DATA(snap).localAng = localAng;
    DATA(snap).PL_dB = PL_dB;
    DATA(snap).randCorrect = rand(N,1);
    DATA(snap).randNeighbor = rand(N,1);
    DATA(snap).randInterfBeam = rand(N, P.numPairs);
end
end

function [metrics, rows, secTput] = evaluate_solution(Kvec, P, DATA, returnRows)
% Identical to the model used in all earlier rounds; the only addition is the
% third output secTput (mean effective throughput of the users of each sector),
% which is needed by the local reward of RL Variant A. Metrics are unchanged.
if nargin < 4
    returnRows = false;
end

Kvec = Kvec(:)';
Nsnap = numel(DATA);
Ntot = 0;
for ss = 1:Nsnap
    Ntot = Ntot + numel(DATA(ss).pairIdx);
end

allSinr_dB = zeros(Ntot,1);
allTput = zeros(Ntot,1);
allInterf_W = zeros(Ntot,1);
allOH = zeros(Ntot,1);

if returnRows
    allSnap = zeros(Ntot,1);
    allBS = zeros(Ntot,1);
    allSec = zeros(Ntot,1);
    allPair = zeros(Ntot,1);
    allK = zeros(Ntot,1);
    allLoad = zeros(Ntot,1);
    allPcorrect = zeros(Ntot,1);
    allX = zeros(Ntot,1);
    allY = zeros(Ntot,1);
end

sectorOH = compute_sector_overheads(Kvec, P);
ptr = 0;
secSum = zeros(P.numPairs,1);
secCnt = zeros(P.numPairs,1);

for ss = 1:Nsnap
    D = DATA(ss);
    N = numel(D.pairIdx);
    pairIdx = D.pairIdx(:);
    rowIdx = (1:N)';

    Kserv = Kvec(pairIdx);
    Kserv = Kserv(:);
    HPBWserv = P.sectorSpan_deg ./ Kserv;

    indServ = sub2ind([N P.numPairs], rowIdx, pairIdx);
    thServ = D.localAng(indServ);

    % Serving users are generated inside their serving sector, but we still
    % clamp numerically to [0,120) for robust beam-index calculation.
    thServForIndex = thServ;
    thServForIndex(thServForIndex < 0) = 0;
    thServForIndex(thServForIndex >= P.sectorSpan_deg) = P.sectorSpan_deg - eps;

    PLserv = D.PL_dB(indServ);

    % Uniform sector codebook: center angles are (0.5:1:K-0.5)*HPBW.
    bestBeamIdx = floor(thServForIndex ./ HPBWserv) + 1;
    bestBeamIdx = max(bestBeamIdx, 1);
    bestBeamIdx = min(bestBeamIdx, Kserv);

    chosenBeamIdx = bestBeamIdx;

    % Corrected beam-selection model: p_correct is K-dependent. Narrower beams
    % are more sensitive to angular error and therefore have a lower chance of
    % selecting the exact best beam.
    pCorrectUser = beam_correct_probability(Kserv, P);
    miss = D.randCorrect(:) > pCorrectUser;
    if any(miss)
        onlyLeft = miss & (bestBeamIdx == Kserv) & (Kserv > 1);
        onlyRight = miss & (bestBeamIdx == 1) & (Kserv > 1);
        middle = miss & (bestBeamIdx > 1) & (bestBeamIdx < Kserv);

        chosenBeamIdx(onlyLeft) = bestBeamIdx(onlyLeft) - 1;
        chosenBeamIdx(onlyRight) = bestBeamIdx(onlyRight) + 1;

        midIdx = find(middle);
        if ~isempty(midIdx)
            chosenBeamIdx(midIdx) = bestBeamIdx(midIdx) - 1;
            chooseRight = D.randNeighbor(midIdx) >= 0.5;
            chosenBeamIdx(midIdx(chooseRight)) = bestBeamIdx(midIdx(chooseRight)) + 1;
        end
    end

    beamCenterServ = (chosenBeamIdx - 0.5) .* HPBWserv;
    deltaServ = abs(wrap180_local(thServ - beamCenterServ));
    Gserv = beam_gain(deltaServ, HPBWserv, P.antennaGain_dBi, P.frontBackLimit_dB);
    g_eff = 10.^((Gserv - PLserv)/10);

    % Load-aware inter-sector interference from all non-serving sectors.
    % Each interfering sector has its own rho based on its current snapshot load.
    I_W = zeros(N,1);
    for q = 1:P.numPairs
        active = pairIdx ~= q;
        if ~any(active)
            continue;
        end
        Kq = Kvec(q);
        HPBWq = P.sectorSpan_deg / Kq;
        intBeamIdx = floor(D.randInterfBeam(:,q) * Kq) + 1;
        intBeamIdx = max(intBeamIdx, 1);
        intBeamIdx = min(intBeamIdx, Kq);
        beamCenterI = (intBeamIdx - 0.5) * HPBWq;

        % Corrected: localAng can be outside [0,120). The wrapped angular
        % distance to the selected interfering beam center is used directly.
        deltaI = abs(wrap180_local(D.localAng(:,q) - beamCenterI));
        GI = beam_gain(deltaI, HPBWq, P.antennaGain_dBi, P.frontBackLimit_dB);
        Iterm = P.eta_overlap * D.rhoSector(q) * 10.^((P.Pt_dBm + GI - D.PL_dB(:,q) - 30)/10);
        I_W(active) = I_W(active) + Iterm(active);
    end

    sinrLinear = P.Pt_W * g_eff ./ (P.noise_W + I_W);
    sinr_dB = 10*log10(max(sinrLinear, realmin));
    OHuser = sectorOH(pairIdx);

    % No WF: equal resource share among the users currently assigned to the
    % same sector. With non-uniform load, bandwidth share is sector-dependent.
    loadUser = D.sectorLoad(pairIdx);
    loadUser = max(loadUser(:), 1);
    tput = (P.BW_Hz ./ loadUser) .* log2(1 + sinrLinear) / 1e6 .* (1 - OHuser);

    idxOut = ptr + (1:N);
    allSinr_dB(idxOut) = sinr_dB;
    allTput(idxOut) = tput;
    secSum = secSum + accumarray(pairIdx, tput, [P.numPairs 1]);
    secCnt = secCnt + accumarray(pairIdx, ones(N,1), [P.numPairs 1]);
    allInterf_W(idxOut) = I_W;
    allOH(idxOut) = OHuser;

    if returnRows
        allSnap(idxOut) = ss;
        allBS(idxOut) = D.bsIdx;
        allSec(idxOut) = D.secIdx;
        allPair(idxOut) = pairIdx;
        allK(idxOut) = Kserv;
        allLoad(idxOut) = loadUser;
        allPcorrect(idxOut) = pCorrectUser;
        allX(idxOut) = D.x_m;
        allY(idxOut) = D.y_m;
    end

    ptr = ptr + N;
end

metrics = struct();
secTput = secSum ./ max(secCnt, 1);
metrics.AvgSINR_dB = mean(allSinr_dB);
metrics.P5SINR_dB = prctile(allSinr_dB, 5);
metrics.Coverage_pct = 100 * mean(allSinr_dB > P.coverageThreshold_dB);
metrics.AvgEffTput_Mbps = mean(allTput);
metrics.JFI = jain_fairness(allTput);
metrics.AvgOverhead = mean(allOH);
metrics.AvgOverhead_percent = 100 * metrics.AvgOverhead;
metrics.AvgInterference_W = mean(allInterf_W);
metrics.AvgInterference_dBm = 10*log10(max(metrics.AvgInterference_W, realmin)*1000);
metrics.P5Tput_Mbps = prctile(allTput, 5);
metrics.MedianTput_Mbps = median(allTput);

if returnRows
    interf_dBm = 10*log10(max(allInterf_W, realmin)*1000);
    rows = table(allSnap, allBS, allSec, allPair, allK, allLoad, allPcorrect, allX, allY, ...
        allSinr_dB, allTput, allOH, 100*allOH, allInterf_W, interf_dBm, ...
        'VariableNames', {'snapshot','bs','sector','pair','numBeams','sectorLoad','pCorrectBeam','x_m','y_m', ...
        'sinr_dB','tput_Mbps','overhead','overhead_percent','interference_W','interference_dBm'});
else
    rows = [];
end
end

function Kvec = heuristic_beam_vector(P, mode)
% HEURISTIC_BEAM_VECTOR  Simple closed-form, load-aware beam-count rule (no optimization).
% The NOMINAL sector load profile is linearly mapped onto [Kmin, Kmax] and
% snapped to the nearest candidate beam count.
%   'proportional': higher load -> more beams.
%   'inverse'     : higher load -> fewer beams.
nom = P.sectorLoadProfile(:)';
lo = min(nom); hi = max(nom);
Kmin = min(P.beamCandidates); Kmax = max(P.beamCandidates);
t = (nom - lo) / (hi - lo);
if strcmp(mode, 'inverse')
    t = 1 - t;
end
target = Kmin + t * (Kmax - Kmin);
Kvec = zeros(1, numel(target));
for q = 1:numel(target)
    [~, j] = min(abs(P.beamCandidates - target(q)));
    Kvec(q) = P.beamCandidates(j);
end
end

function sectorOH = compute_sector_overheads(Kvec, P)
Kvec = Kvec(:)';

% Corrected overhead model:
% 1) SSB sweeping overhead grows with K.
% 2) CSI/beam refinement overhead also grows with K, instead of being fixed.
% 3) A normalized beam-management complexity penalty is included to represent
%    search latency, measurement/reporting burden, and control complexity.
OH_SSB = Kvec * P.T_SSB_ms / P.T_ssb_period_ms;
OH_CSI = Kvec * P.Tsym_ms / P.T_csi_period_ms;

Kmin = min(P.beamCandidates);
Kmax = max(P.beamCandidates);
if Kmax > Kmin
    Knorm = (Kvec - Kmin) / (Kmax - Kmin);
else
    Knorm = zeros(size(Kvec));
end
OH_complexity = P.beamComplexityPenaltyMax * (Knorm .^ P.beamComplexityPenaltyPower);

sectorOH = min(OH_SSB + OH_CSI + OH_complexity, P.OH_cap);
sectorOH = sectorOH(:);
end

function [FoM, normMetrics] = compute_fom_equal_weights(metrics)
% metrics columns:
% 1 AvgEffTput_Mbps        benefit
% 2 P5SINR_dB              benefit
% 3 JFI                    benefit
% 4 AvgOverhead_percent    cost
% 5 AvgInterference_dBm    cost
% 6 Coverage_pct           reporting only
% 7 AvgSINR_dB             reporting only
% 8 P5Tput_Mbps            reporting only

X = metrics(:,1:5);
benefit = [true true true false false];
normMetrics = zeros(size(X));

for j = 1:5
    x = X(:,j);
    xmin = min(x);
    xmax = max(x);
    if abs(xmax - xmin) < 1e-12
        normMetrics(:,j) = ones(size(x));
    else
        if benefit(j)
            normMetrics(:,j) = (x - xmin) / (xmax - xmin);
        else
            normMetrics(:,j) = (xmax - x) / (xmax - xmin);
        end
    end
end

weights = ones(1,5)/5;
FoM = normMetrics * weights(:);
end

function loadVec = generate_sector_loads(P)
if isfield(P, 'useNonUniformLoad') && P.useNonUniformLoad
    loadVec = P.sectorLoadProfile(:);
    jitter = round((2*rand(P.numPairs,1) - 1) * P.loadJitterUE);
    loadVec = loadVec + jitter;
    loadVec = max(P.minUEsPerSec, min(P.maxUEsPerSec, loadVec));
else
    loadVec = P.UEsPerSec * ones(P.numPairs,1);
end
loadVec = round(loadVec(:));
end

function [bs, sec] = pair_to_bssec(pair, P)
bs = floor((pair-1)/P.numSec) + 1;
sec = mod(pair-1, P.numSec) + 1;
end

function pCorr = beam_correct_probability(K, P)
% K-dependent beam-selection probability. The reference is pCorrectAt8 at
% K=8. Larger K means narrower beams and a higher probability of beam-index
% error; smaller K means wider beams and a more robust selection.
pCorr = P.pCorrectAt8 - P.pCorrectSlope * (K - 8);
pCorr = max(P.pCorrectMin, min(P.pCorrectMax, pCorr));
end

function PLdB = path_loss_uma_simple(d_m, f_Hz)
% Close, simple UMa-like path-loss expression retained from the original code.
% If your manuscript states the full 3GPP TR 38.901 UMa LOS/NLOS model,
% replace this function with the exact TR 38.901 implementation.
f_GHz = f_Hz/1e9;
d_m = max(d_m, 1);
PLdB = 32.4 + 21*log10(d_m) + 20*log10(f_GHz);
end

function G = beam_gain(delta, HPBW, Gmax, Am)
G = Gmax - min(12*(delta./HPBW).^2, Am);
end

function ang = wrap180_local(ang)
ang = mod(ang + 180, 360) - 180;
end

function J = jain_fairness(x)
x = x(:);
x(~isfinite(x)) = 0;
den = numel(x)*sum(x.^2);
if den <= 0
    J = 0;
else
    J = (sum(x)^2)/den;
end
end

function pop = generate_initial_population(P, seedValue)
% Identical initial genomes are supplied to NSGA-III and MOWOA.
rng(seedValue, 'twister');
pop = randi(P.numCandidates, P.popSize, P.numDecisionVars);
for c = 1:min(P.numCandidates, P.popSize)
    pop(c,:) = c;
end
end

function NSGA = run_nsga3(P, DATAopt, initialPop)
D = P.numDecisionVars;
N = P.popSize;

rng(P.seedNSGAOperators, 'twister');
pop = initialPop;
if size(pop,1) ~= N || size(pop,2) ~= D
    error('NSGA-III initial population dimensions do not match P.popSize and P.numDecisionVars.');
end

[obj, metrics] = evaluate_population(pop, P, DATAopt);
[~, rank] = non_dominated_sort(obj);

% Dual archives:
%   historicalArchive: unbounded global non-dominated set over all evaluations.
%   workingArchive   : bounded crowding-distance subset, Aworking = 70.
[historicalPop, historicalObj, historicalMetrics] = update_pareto_archive( ...
    [], [], [], pop, obj, metrics);
[workingPop, workingObj, workingMetrics] = truncate_pareto_archive( ...
    historicalPop, historicalObj, historicalMetrics, P.workingArchiveSize);

history = initialize_optimizer_history(P.maxGen);

for gen = 1:P.maxGen
    matingPool = tournament_selection(pop, rank, obj, N);
    offspring = make_offspring(matingPool, P);
    [objOff, metricsOff] = evaluate_population(offspring, P, DATAopt);

    [historicalPop, historicalObj, historicalMetrics] = update_pareto_archive( ...
        historicalPop, historicalObj, historicalMetrics, ...
        offspring, objOff, metricsOff);
    [workingPop, workingObj, workingMetrics] = truncate_pareto_archive( ...
        historicalPop, historicalObj, historicalMetrics, P.workingArchiveSize);

    combPop = [pop; offspring];
    combObj = [obj; objOff];
    combMetrics = [metrics; metricsOff];

    [pop, obj, metrics, rank] = environmental_selection_nsga3( ...
        combPop, combObj, combMetrics, N, P.refPoints);

    history = update_optimizer_history(history, gen, rank, metrics, ...
        workingPop, workingMetrics, historicalPop, historicalMetrics);

    if mod(gen,5) == 0 || gen == 1 || gen == P.maxGen
        fprintf(['NSGA-III generation %3d/%3d | Pareto=%3d | Working=%3d | ' ...
            'Historical=%3d | Best Historical FoM=%.4f | Best AvgTput=%.3f Mbps | ' ...
            'Best P5SINR=%.3f dB\n'], ...
            gen, P.maxGen, history.ParetoCount(gen), ...
            history.WorkingArchiveCount(gen), history.HistoricalArchiveCount(gen), ...
            history.BestHistoricalArchiveFoM(gen), history.BestAvgTput_Mbps(gen), ...
            history.BestP5SINR_dB(gen));
    end
end

NSGA = struct();
NSGA.population = pop;
NSGA.Kpopulation = decode_population(pop, P);
NSGA.objectives = obj;
NSGA.metrics = metrics;
NSGA.rank = rank;

NSGA.workingArchive = struct();
NSGA.workingArchive.population = workingPop;
NSGA.workingArchive.Kpopulation = decode_population(workingPop, P);
NSGA.workingArchive.objectives = workingObj;
NSGA.workingArchive.metrics = workingMetrics;
NSGA.workingArchive.limit = P.workingArchiveSize;

NSGA.historicalArchive = struct();
NSGA.historicalArchive.population = historicalPop;
NSGA.historicalArchive.Kpopulation = decode_population(historicalPop, P);
NSGA.historicalArchive.objectives = historicalObj;
NSGA.historicalArchive.metrics = historicalMetrics;
NSGA.historicalArchive.limit = inf;

% Backward-compatible alias: final analysis archive is the historical archive.
NSGA.archive = NSGA.historicalArchive;
NSGA.history = history;
NSGA.metricColumns = {'AvgEffTput_Mbps','P5SINR_dB','JFI','AvgOverhead_percent','AvgInterference_dBm','Coverage_pct','AvgSINR_dB','P5Tput_Mbps'};
NSGA.objectiveColumns = {'min_negative_AvgEffTput','min_negative_P5SINR','min_negative_JFI','min_AvgOverhead_percent','min_AvgInterference_dBm'};
NSGA.approximateEvaluations = P.popSize*(P.maxGen+1);
end

function MOWOA = run_mowoa(P, DATAopt, initialPop)
% Multi-Objective Whale Optimization Algorithm for discrete candidate indices.
N = P.popSize;
D = P.numDecisionVars;

rng(P.seedMOWOAOperators, 'twister');
positions = double(initialPop);
pop = discretize_whale_positions(positions, P);
[obj, metrics] = evaluate_population(pop, P, DATAopt);

% Dual archives:
%   historicalArchive: unbounded global non-dominated set over all evaluations.
%   workingArchive   : bounded archive used exclusively for leader selection.
[historicalPop, historicalObj, historicalMetrics] = update_pareto_archive( ...
    [], [], [], pop, obj, metrics);
[workingPop, workingObj, workingMetrics] = truncate_pareto_archive( ...
    historicalPop, historicalObj, historicalMetrics, P.workingArchiveSize);

history = initialize_optimizer_history(P.maxGen);

for iter = 1:P.maxGen
    if P.maxGen > 1
        progress = (iter-1)/(P.maxGen-1);
    else
        progress = 1;
    end
    a = 2 - 2*progress;          % Exploration-to-exploitation coefficient.
    a2 = -1 - progress;          % Standard spiral l-range decreases -1 to -2.

    newPositions = zeros(N,D);
    for i = 1:N
        % Leaders are selected only from the bounded working archive.
        leaderGenome = select_mowoa_leader(workingPop, workingObj);
        leaderPosition = double(leaderGenome);
        currentPosition = positions(i,:);

        r1 = rand;
        r2 = rand;
        A = 2*a*r1 - a;
        C = 2*r2;
        p = rand;

        if p < 0.5
            if abs(A) < 1
                % Encircling/exploitation toward a non-dominated archive leader.
                distance = abs(C*leaderPosition - currentPosition);
                candidatePosition = leaderPosition - A*distance;
            else
                % Global exploration around another randomly selected whale.
                randomIndex = randi(N);
                randomPosition = positions(randomIndex,:);
                distance = abs(C*randomPosition - currentPosition);
                candidatePosition = randomPosition - A*distance;
            end
        else
            % Logarithmic spiral exploitation around the archive leader.
            distance = abs(leaderPosition - currentPosition);
            l = (a2 - 1)*rand + 1;
            candidatePosition = distance .* exp(P.mowoaSpiralB*l) .* ...
                cos(2*pi*l) + leaderPosition;
        end

        newPositions(i,:) = candidatePosition;
    end

    % Bound, discretize, and apply the same per-variable mutation probability
    % used in NSGA-III. Mutation here is a discrete diversification operator,
    % not a replacement for the native WOA movement equations.
    newPositions = max(1, min(P.numCandidates, newPositions));
    pop = discretize_whale_positions(newPositions, P);
    for i = 1:N
        pop(i,:) = mutate_integer_genome(pop(i,:), P);
    end
    positions = double(pop);

    [obj, metrics] = evaluate_population(pop, P, DATAopt);
    [historicalPop, historicalObj, historicalMetrics] = update_pareto_archive( ...
        historicalPop, historicalObj, historicalMetrics, pop, obj, metrics);
    [workingPop, workingObj, workingMetrics] = truncate_pareto_archive( ...
        historicalPop, historicalObj, historicalMetrics, P.workingArchiveSize);
    [~, rank] = non_dominated_sort(obj);

    history = update_optimizer_history(history, iter, rank, metrics, ...
        workingPop, workingMetrics, historicalPop, historicalMetrics);

    if mod(iter,5) == 0 || iter == 1 || iter == P.maxGen
        fprintf(['MOWOA iteration  %3d/%3d | Pareto=%3d | Working=%3d | ' ...
            'Historical=%3d | Best Historical FoM=%.4f | Best AvgTput=%.3f Mbps | ' ...
            'Best P5SINR=%.3f dB\n'], ...
            iter, P.maxGen, history.ParetoCount(iter), ...
            history.WorkingArchiveCount(iter), history.HistoricalArchiveCount(iter), ...
            history.BestHistoricalArchiveFoM(iter), history.BestAvgTput_Mbps(iter), ...
            history.BestP5SINR_dB(iter));
    end
end

MOWOA = struct();
MOWOA.population = pop;
MOWOA.Kpopulation = decode_population(pop, P);
MOWOA.objectives = obj;
MOWOA.metrics = metrics;
MOWOA.rank = rank;

MOWOA.workingArchive = struct();
MOWOA.workingArchive.population = workingPop;
MOWOA.workingArchive.Kpopulation = decode_population(workingPop, P);
MOWOA.workingArchive.objectives = workingObj;
MOWOA.workingArchive.metrics = workingMetrics;
MOWOA.workingArchive.limit = P.workingArchiveSize;

MOWOA.historicalArchive = struct();
MOWOA.historicalArchive.population = historicalPop;
MOWOA.historicalArchive.Kpopulation = decode_population(historicalPop, P);
MOWOA.historicalArchive.objectives = historicalObj;
MOWOA.historicalArchive.metrics = historicalMetrics;
MOWOA.historicalArchive.limit = inf;

% Backward-compatible alias: final analysis archive is the historical archive.
MOWOA.archive = MOWOA.historicalArchive;
MOWOA.history = history;
MOWOA.metricColumns = {'AvgEffTput_Mbps','P5SINR_dB','JFI','AvgOverhead_percent','AvgInterference_dBm','Coverage_pct','AvgSINR_dB','P5Tput_Mbps'};
MOWOA.objectiveColumns = {'min_negative_AvgEffTput','min_negative_P5SINR','min_negative_JFI','min_AvgOverhead_percent','min_AvgInterference_dBm'};
MOWOA.approximateEvaluations = P.popSize*(P.maxGen+1);
end

function pop = discretize_whale_positions(positions, P)
pop = round(positions);
pop = max(1, min(P.numCandidates, pop));
pop = double(pop);
end

function leader = select_mowoa_leader(archivePop, archiveObj)
% Select leaders preferentially from sparse regions of the Pareto archive.
if isempty(archivePop)
    error('MOWOA archive is empty; a leader cannot be selected.');
end
if size(archivePop,1) == 1
    leader = archivePop(1,:);
    return;
end

crowd = crowding_distance_multiobjective(archiveObj);
finiteCrowd = crowd(isfinite(crowd));
if isempty(finiteCrowd)
    weights = ones(size(crowd));
else
    maxFinite = max(finiteCrowd);
    if maxFinite <= 0
        maxFinite = 1;
    end
    crowd(~isfinite(crowd)) = 2*maxFinite;
    crowd(crowd < 0) = 0;
    weights = crowd + 1e-12;
end

weights = weights / sum(weights);
r = rand;
cumulative = cumsum(weights);
idx = find(cumulative >= r, 1, 'first');
if isempty(idx)
    idx = numel(weights);
end
leader = archivePop(idx,:);
end

function [workingPop, workingObj, workingMetrics] = truncate_pareto_archive( ...
    historicalPop, historicalObj, historicalMetrics, maxSize)
% TRUNCATE_PARETO_ARCHIVE
% Creates the bounded working archive from the complete historical Pareto
% archive. Crowding distance preserves sparse and boundary regions.
workingPop = historicalPop;
workingObj = historicalObj;
workingMetrics = historicalMetrics;

if size(workingPop,1) > maxSize
    crowd = crowding_distance_multiobjective(workingObj);
    [~, order] = sort(crowd, 'descend');
    keep = order(1:maxSize);
    workingPop = workingPop(keep,:);
    workingObj = workingObj(keep,:);
    workingMetrics = workingMetrics(keep,:);
end
end

function distance = crowding_distance_multiobjective(obj)
N = size(obj,1);
M = size(obj,2);
distance = zeros(N,1);
if N <= 2
    distance(:) = inf;
    return;
end

for m = 1:M
    [values, order] = sort(obj(:,m));
    distance(order(1)) = inf;
    distance(order(end)) = inf;
    rangeValue = values(end) - values(1);
    if abs(rangeValue) < eps
        continue;
    end
    for i = 2:N-1
        if isfinite(distance(order(i)))
            distance(order(i)) = distance(order(i)) + ...
                (values(i+1) - values(i-1))/rangeValue;
        end
    end
end
end

function H = initialize_optimizer_history(nCycles)
H = struct();
H.BestFoM = zeros(nCycles,1);
H.ParetoCount = zeros(nCycles,1);
H.BestAvgTput_Mbps = zeros(nCycles,1);
H.BestP5SINR_dB = zeros(nCycles,1);
H.BestJFI = zeros(nCycles,1);
H.MinOverhead_percent = zeros(nCycles,1);
H.MinInterference_dBm = zeros(nCycles,1);
H.WorkingArchiveCount = zeros(nCycles,1);
H.HistoricalArchiveCount = zeros(nCycles,1);
H.BestWorkingArchiveFoM = zeros(nCycles,1);
H.BestHistoricalArchiveFoM = zeros(nCycles,1);

% Backward-compatible aliases populated during each update.
H.ArchiveCount = zeros(nCycles,1);
H.BestArchiveFoM = zeros(nCycles,1);
end

function H = update_optimizer_history(H, cycle, rank, metrics, ...
    workingPop, workingMetrics, historicalPop, historicalMetrics)
pf = rank == 1;
H.ParetoCount(cycle) = sum(pf);
H.BestAvgTput_Mbps(cycle) = max(metrics(:,1));
H.BestP5SINR_dB(cycle) = max(metrics(:,2));
H.BestJFI(cycle) = max(metrics(:,3));
H.MinOverhead_percent(cycle) = min(metrics(:,4));
H.MinInterference_dBm(cycle) = min(metrics(:,5));

if any(pf)
    f = compute_fom_equal_weights(metrics(pf,:));
    H.BestFoM(cycle) = max(f);
end

H.WorkingArchiveCount(cycle) = size(workingPop,1);
H.HistoricalArchiveCount(cycle) = size(historicalPop,1);

if ~isempty(workingMetrics)
    fWorking = compute_fom_equal_weights(workingMetrics);
    H.BestWorkingArchiveFoM(cycle) = max(fWorking);
end
if ~isempty(historicalMetrics)
    fHistorical = compute_fom_equal_weights(historicalMetrics);
    H.BestHistoricalArchiveFoM(cycle) = max(fHistorical);
end

% Backward-compatible aliases refer to the bounded working archive.
H.ArchiveCount(cycle) = H.WorkingArchiveCount(cycle);
H.BestArchiveFoM(cycle) = H.BestWorkingArchiveFoM(cycle);
end

function [archivePop, archiveObj, archiveMetrics] = update_pareto_archive(archivePop, archiveObj, archiveMetrics, newPop, newObj, newMetrics)
% UPDATE_PARETO_ARCHIVE
% Keeps only unique non-dominated genomes among the previous archive and the
% newly evaluated solutions. Objectives are minimization objectives.
if isempty(archivePop)
    allPop = newPop;
    allObj = newObj;
    allMetrics = newMetrics;
else
    allPop = [archivePop; newPop];
    allObj = [archiveObj; newObj];
    allMetrics = [archiveMetrics; newMetrics];
end

% Remove duplicate genomes to keep the archive compact and deterministic.
[~, ia] = unique(allPop, 'rows', 'stable');
allPop = allPop(ia,:);
allObj = allObj(ia,:);
allMetrics = allMetrics(ia,:);

[~, arank] = non_dominated_sort(allObj);
keep = arank == 1;
archivePop = allPop(keep,:);
archiveObj = allObj(keep,:);
archiveMetrics = allMetrics(keep,:);
end

function [obj, metrics] = evaluate_population(pop, P, DATAopt)
N = size(pop,1);
obj = zeros(N, P.numObjectives);
metrics = zeros(N, 8);

for i = 1:N
    Kvec = P.beamCandidates(pop(i,:));
    m = evaluate_solution(Kvec, P, DATAopt, false);
    metrics(i,:) = [m.AvgEffTput_Mbps, m.P5SINR_dB, m.JFI, ...
                    m.AvgOverhead_percent, m.AvgInterference_dBm, ...
                    m.Coverage_pct, m.AvgSINR_dB, m.P5Tput_Mbps];

    % NSGA-III implementation below is formulated as minimization.
    % Maximization objectives are multiplied by -1.
    obj(i,:) = [-m.AvgEffTput_Mbps, -m.P5SINR_dB, -m.JFI, ...
                 m.AvgOverhead_percent, m.AvgInterference_dBm];
end
end

function Kpop = decode_population(pop, P)
Kpop = P.beamCandidates(pop);
end

% =========================================================================
% NSGA-III operators
% =========================================================================

function matingPool = tournament_selection(pop, rank, obj, N)
D = size(pop,2);
matingPool = zeros(N,D);

% Normalized-objective tie-breaker:
% The five objectives have different numerical scales, so raw summation can
% bias parent selection toward the objective with the largest magnitude.
% Normalizing here reduces premature convergence caused by scale dominance.
normObj = normalize_objectives(obj);

for i = 1:N
    a = randi(N);
    b = randi(N);
    if rank(a) < rank(b)
        winner = a;
    elseif rank(b) < rank(a)
        winner = b;
    else
        % Tie-breaker: smaller aggregate normalized objective value.
        za = sum(normObj(a,:));
        zb = sum(normObj(b,:));
        if za < zb
            winner = a;
        elseif zb < za
            winner = b;
        else
            if rand < 0.5
                winner = a;
            else
                winner = b;
            end
        end
    end
    matingPool(i,:) = pop(winner,:);
end
end

function offspring = make_offspring(parents, P)
N = size(parents,1);
D = size(parents,2);
offspring = zeros(N,D);

order = randperm(N);
parents = parents(order,:);

for i = 1:2:N
    p1 = parents(i,:);
    if i+1 <= N
        p2 = parents(i+1,:);
    else
        p2 = parents(randi(N),:);
    end

    c1 = p1;
    c2 = p2;
    if rand < P.pCrossover
        mask = rand(1,D) < 0.5;
        c1(mask) = p2(mask);
        c2(mask) = p1(mask);
    end

    c1 = mutate_integer_genome(c1, P);
    c2 = mutate_integer_genome(c2, P);

    offspring(i,:) = c1;
    if i+1 <= N
        offspring(i+1,:) = c2;
    end
end
end

function g = mutate_integer_genome(g, P)
for j = 1:numel(g)
    if rand < P.pMutation
        oldVal = g(j);
        newVal = randi(P.numCandidates);
        if P.numCandidates > 1
            while newVal == oldVal
                newVal = randi(P.numCandidates);
            end
        end
        g(j) = newVal;
    end
end
end

function [newPop, newObj, newMetrics, newRank] = environmental_selection_nsga3(pop, obj, metrics, N, refPoints)
[fronts, rank] = non_dominated_sort(obj);
selected = [];
lastFront = [];

for f = 1:numel(fronts)
    fr = fronts{f};
    if numel(selected) + numel(fr) <= N
        selected = [selected; fr(:)]; %#ok<AGROW>
    else
        lastFront = fr(:);
        break;
    end
end

if numel(selected) == N
    finalIdx = selected;
else
    remaining = N - numel(selected);
    normObj = normalize_objectives(obj);
    [assocRef, distRef] = associate_to_reference_points(normObj, refPoints);

    nicheCount = zeros(size(refPoints,1),1);
    for i = 1:numel(selected)
        nicheCount(assocRef(selected(i))) = nicheCount(assocRef(selected(i))) + 1;
    end

    candidates = lastFront(:);
    chosenFromLast = [];

    while numel(chosenFromLast) < remaining && ~isempty(candidates)
        candidateRefs = unique(assocRef(candidates));
        counts = nicheCount(candidateRefs);
        minCount = min(counts);
        refPool = candidateRefs(counts == minCount);
        refChosen = refPool(randi(numel(refPool)));

        candForRef = candidates(assocRef(candidates) == refChosen);
        if isempty(candForRef)
            candidates = setdiff(candidates, candForRef);
            continue;
        end

        if nicheCount(refChosen) == 0
            [~, jj] = min(distRef(candForRef));
            pick = candForRef(jj);
        else
            pick = candForRef(randi(numel(candForRef)));
        end

        chosenFromLast = [chosenFromLast; pick]; %#ok<AGROW>
        nicheCount(refChosen) = nicheCount(refChosen) + 1;
        candidates(candidates == pick) = [];
    end

    if numel(chosenFromLast) < remaining && ~isempty(candidates)
        extraNeed = remaining - numel(chosenFromLast);
        rp = randperm(numel(candidates), min(extraNeed, numel(candidates)));
        chosenFromLast = [chosenFromLast; candidates(rp)]; %#ok<AGROW>
    end

    finalIdx = [selected; chosenFromLast(:)];
end

newPop = pop(finalIdx,:);
newObj = obj(finalIdx,:);
newMetrics = metrics(finalIdx,:);
[~, newRank] = non_dominated_sort(newObj);
end

function normObj = normalize_objectives(obj)
zmin = min(obj, [], 1);
shifted = bsxfun(@minus, obj, zmin);
zmax = max(shifted, [], 1);
zmax(zmax < eps) = 1;
normObj = bsxfun(@rdivide, shifted, zmax);
normObj(~isfinite(normObj)) = 0;
end

function [assocRef, distRef] = associate_to_reference_points(normObj, refPoints)
N = size(normObj,1);
R = size(refPoints,1);
assocRef = zeros(N,1);
distRef = zeros(N,1);

refNorm = sqrt(sum(refPoints.^2,2));
refNorm(refNorm < eps) = 1;
refUnit = bsxfun(@rdivide, refPoints, refNorm);

for i = 1:N
    y = normObj(i,:);
    bestD = inf;
    bestR = 1;
    for r = 1:R
        u = refUnit(r,:);
        proj = sum(y .* u) * u;
        d = sqrt(sum((y - proj).^2));
        if d < bestD
            bestD = d;
            bestR = r;
        end
    end
    assocRef(i) = bestR;
    distRef(i) = bestD;
end
end

function [fronts, rank] = non_dominated_sort(obj)
N = size(obj,1);
S = cell(N,1);
n = zeros(N,1);
rank = inf(N,1);
fronts = {};
F1 = [];

for p = 1:N
    S{p} = [];
    n(p) = 0;
    for q = 1:N
        if p == q
            continue;
        end
        if dominates(obj(p,:), obj(q,:))
            S{p} = [S{p} q]; %#ok<AGROW>
        elseif dominates(obj(q,:), obj(p,:))
            n(p) = n(p) + 1;
        end
    end
    if n(p) == 0
        rank(p) = 1;
        F1 = [F1 p]; %#ok<AGROW>
    end
end

fronts{1} = F1;
i = 1;
while ~isempty(fronts{i})
    Q = [];
    for pp = 1:numel(fronts{i})
        p = fronts{i}(pp);
        for qq = 1:numel(S{p})
            q = S{p}(qq);
            n(q) = n(q) - 1;
            if n(q) == 0
                rank(q) = i + 1;
                Q = [Q q]; %#ok<AGROW>
            end
        end
    end
    i = i + 1;
    fronts{i} = Q; %#ok<AGROW>
end
if isempty(fronts{end})
    fronts(end) = [];
end
end

function tf = dominates(a, b)
tf = all(a <= b) && any(a < b);
end

function refPoints = generate_reference_points(M, H)
% Das and Dennis simplex-lattice reference points.
combs = generate_compositions(H, M);
refPoints = combs / H;
refPoints(sum(refPoints,2) == 0, :) = [];
end

function C = generate_compositions(n, k)
if k == 1
    C = n;
else
    C = [];
    for i = 0:n
        sub = generate_compositions(n-i, k-1);
        C = [C; [i*ones(size(sub,1),1), sub]]; %#ok<AGROW>
    end
end
end

% =========================================================================
% Figure of Merit and tables
% =========================================================================

