function plot_rl_curves_R2P1(matFile)
% PLOT_RL_CURVES_R2P1  Re-draws the training-curve figure of the RL baseline from the saved
% results (no re-training needed). The legend is placed so that it does not hide any curve.
% Usage (run in the folder that contains rl_baseline_R2P1_outputs):  plot_rl_curves_R2P1;
if nargin < 1
    matFile = fullfile(pwd, 'rl_baseline_R2P1_outputs', 'RL_BASELINE_R2P1_RESULTS.mat');
end
S = load(matFile);
RES = S.RES;
trA = RES.runTrace{1,1};
trB = RES.runTrace{1,2};
R = RES.R;
w = max(1, min(200, floor(numel(trA)/10)));
sm = @(x) conv(x(:), ones(w,1)/w, 'valid');
f = figure('Color', 'w');
plot(w:numel(trA), sm(trA), 'LineWidth', 1.5); hold on;
plot(w:numel(trB), sm(trB), 'LineWidth', 1.5);
xe = R.epsDecayFrac * R.nSteps;
plot([xe xe], [0 1], 'k--');
ylim([0 1]); xlim([0 numel(trA)]);
grid on; box on;
set(gca, 'FontSize', 11);
xlabel('Training step (joint evaluation)');
ylabel('Shared reward (equal-weight normalized objectives)');
legend({'Variant A (local throughput)', 'Variant B (shared five-objective)', 'End of exploration decay'}, ...
    'Location', 'east', 'FontSize', 9);
outFile = fullfile(fileparts(matFile), 'Fig_R2P1_Learning_Curves_v2.png');
set(f, 'PaperPositionMode', 'auto');
print(f, outFile, '-dpng', '-r300');
fprintf('Saved: %s\n', outFile);
end
