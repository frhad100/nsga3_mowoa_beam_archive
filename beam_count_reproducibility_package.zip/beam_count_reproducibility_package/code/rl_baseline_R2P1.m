function RES = rl_baseline_R2P1(nRuns, nStepsOverride, snapOverride)
% RL_BASELINE_R2P1  Round-2, Point 1: head-to-head comparison with a recent
% (2024) reinforcement-learning beam-management method under the SAME network
% model, Monte Carlo data, objectives, evaluation budget and decision criterion
% as NSGA-III and MOWOA.
%
% Re-implemented method (adapted):
%   H. Lee, J. Kim, J. So, "Reinforcement Learning-Based Joint Beamwidth and Beam
%   Alignment Interval Optimization in V2I Communications," Sensors 24(3):837, 2024.
%   Core of that method: tabular Q-learning with epsilon-greedy exploration and the
%   Bellman update  Q(s,a) <- (1-alpha) Q(s,a) + alpha [ r + gamma max_a' Q(s',a') ],
%   whose actions are the beamwidth (here: the number of beams K = 120 deg/beamwidth).
%
% Adaptation to the present problem (declared in the manuscript):
%   * One independent Q-learning agent per sector (21 agents), each choosing its own
%     beam count from the same nine candidates [2 3 4 6 8 10 15 20 24].
%   * The scenario is static (no vehicle mobility), so the state collapses to a single
%     state per agent (the agent's sector); the Bellman target is kept with gamma = 0.5.
%   * The beam-alignment interval of the original method is not a decision variable
%     here (the SSB/CSI periods are fixed in the network model).
%   * Same training budget as the metaheuristics: 70*(100+1) = 7070 joint evaluations
%     on the SAME 25-snapshot optimization data (seed 41001); the learned (greedy)
%     policy is evaluated on the SAME 200-snapshot evaluation data (seed 51001).
%
% Two reward variants (both reported):
%   Variant A ("original objective"): each agent receives its OWN sector's mean
%       effective throughput (net of beam-management overhead) - local reward, as in
%       the throughput-centred reward of the original method.
%   Variant B ("common criterion")  : all agents receive the SAME shared reward, the
%       equal-weight mean of the five normalized objectives (throughput, 5%-tile SINR,
%       Jain fairness, overhead, interference) - i.e. the same equal-weight criterion
%       that NSGA-III / MOWOA use. Normalization bounds are fixed in advance from the
%       nine homogeneous configurations evaluated on the optimization data.
%
% The reference NSGA-III and MOWOA beam vectors are the nominal-scenario results of
% the published study (identical to those used in the sensitivity analysis), and
% are re-evaluated here on the same evaluation data.
%
% Usage:
%   RES = rl_baseline_R2P1;          % one learning run per variant (about 15 min each)
%   RES = rl_baseline_R2P1(3);       % three independent learning runs per variant
%   RES = rl_baseline_R2P1(1, 300, [4 20]);   % quick functional test only
% -------------------------------------------------------------------------
if nargin < 1 || isempty(nRuns), nRuns = 1; end
if nargin < 2, nStepsOverride = []; end
if nargin < 3, snapOverride = []; end
close all;

outDir = fullfile(pwd, 'rl_baseline_R2P1_outputs');
if ~exist(outDir, 'dir'), mkdir(outDir); end
logFile = fullfile(outDir, 'console_log.txt');
if exist(logFile, 'file'), delete(logFile); end
diary(logFile);
diaryGuard = onCleanup(@() diary('off'));

% ------------------------------ network model -----------------------------
P = nominal_params();
P.seedOptData = 41001;
P.popSize = 70;               % budget definition shared with NSGA-III / MOWOA
P.maxGen = 100;
if ~isempty(snapOverride)
    P.NsnapOpt = snapOverride(1); P.NsnapEval = snapOverride(2);
end

% ------------------------------ RL settings --------------------------------
R.nSteps = P.popSize * (P.maxGen + 1);       % 7070 joint evaluations (= NSGA-III / MOWOA)
if ~isempty(nStepsOverride), R.nSteps = nStepsOverride; end
R.gamma = 0.5;                  % discount factor
R.alphaMin = 0.02;              % learning-rate floor
R.alphaExp = 0.6;               % alpha = max(alphaMin, 1/n^alphaExp), n = visits of (agent, action)
R.epsStart = 1.0;               % epsilon-greedy: exponential decay ...
R.epsEnd = 0.02;                % ... to epsEnd ...
R.epsDecayFrac = 0.70;          % ... over the first 70 % of the steps
R.seedBase = 64001;             % RL exploration seed (NSGA 62001, MOWOA 63001)
R.nRuns = nRuns;

fprintf('\nRL baseline (Round 2, Point 1): per-sector tabular Q-learning, adapted from Lee et al., Sensors 2024\n');
fprintf('Network: %d BSs x %d sectors = %d agents; candidates: ', P.numBS, P.numSec, P.numPairs);
fprintf('%d ', P.beamCandidates); fprintf('\n');
fprintf('Training budget: %d joint evaluations on %d optimization snapshots (NSGA-III/MOWOA: %d)\n', ...
    R.nSteps, P.NsnapOpt, P.popSize*(P.maxGen+1));
fprintf('gamma=%.2f, alpha=max(%.2f,1/n^%.1f), eps %.2f->%.2f over %.0f%% of steps, runs=%d\n\n', ...
    R.gamma, R.alphaMin, R.alphaExp, R.epsStart, R.epsEnd, 100*R.epsDecayFrac, R.nRuns);

% ------------------------------ common data --------------------------------
fprintf('Generating optimization data (seed %d) and evaluation data (seed %d)...\n', P.seedOptData, P.seedEvalData);
DATAopt  = generate_mc_data(P, P.NsnapOpt,  P.seedOptData);
DATAeval = generate_mc_data(P, P.NsnapEval, P.seedEvalData);

% Fixed normalization bounds for the shared reward (nine homogeneous configurations, optimization data).
M5hom = zeros(P.numCandidates, 5);
for kk = 1:P.numCandidates
    m = evaluate_solution(P.beamCandidates(kk)*ones(1,P.numPairs), P, DATAopt, false);
    M5hom(kk,:) = metric5(m);
end
bounds.lo = min(M5hom, [], 1);
bounds.hi = max(M5hom, [], 1);
fprintf('Reward normalization bounds (from homogeneous configurations on optimization data):\n');
fprintf('  lo = '); fprintf('%10.4f', bounds.lo); fprintf('\n  hi = '); fprintf('%10.4f', bounds.hi); fprintf('\n');

% ------------------------------ reference configurations -------------------
K_NSGA  = [8 15 20 8 10 15 8 24 15 15 8 10 10 24 8 8 6 24 15 8 8];
K_MOWOA = [6 10 10 8 10 15 10 15 10 15 8 8 8 24 6 4 4 20 10 10 6];
HeurPropK = heuristic_beam_vector(P, 'proportional');
HeurInvK  = heuristic_beam_vector(P, 'inverse');

names = cell(1, 15);
Kref = cell(1, 13);
for kk = 1:P.numCandidates
    names{kk} = sprintf('Fixed %d', P.beamCandidates(kk));
    Kref{kk} = P.beamCandidates(kk)*ones(1,P.numPairs);
end
names{10} = 'Load-prop heuristic'; Kref{10} = HeurPropK;
names{11} = 'Inverse-load heuristic'; Kref{11} = HeurInvK;
names{12} = 'NSGA-III'; Kref{12} = K_NSGA;
names{13} = 'MOWOA'; Kref{13} = K_MOWOA;
names{14} = 'RL-A (local throughput)';
names{15} = 'RL-B (shared 5-obj. reward)';

refMetrics = cell(1, 13);
for kk = 1:13
    refMetrics{kk} = evaluate_solution(Kref{kk}, P, DATAeval, false);
end

% Reproduction check against the published Table 3 (only valid for the full-size data).
if isempty(snapOverride)
    chk = [refMetrics{5}.AvgEffTput_Mbps, 27.9646; refMetrics{9}.AvgEffTput_Mbps, 26.8127; ...
           refMetrics{12}.AvgEffTput_Mbps, 28.2430; refMetrics{13}.AvgEffTput_Mbps, 27.8439];
    if any(abs(chk(:,1) - chk(:,2)) > 5e-4)
        warning('Reproduction check FAILED: Fixed8/Fixed24/NSGA-III/MOWOA differ from the published Table 3.');
    else
        fprintf('Reproduction check passed: Fixed 8, Fixed 24, NSGA-III and MOWOA match the published Table 3.\n');
    end
end

% ------------------------------ learning runs ------------------------------
runK = zeros(nRuns, P.numPairs, 2);         % (:,:,1)=A, (:,:,2)=B
runMetrics = cell(nRuns, 2);
runQ = cell(nRuns, 2);
runTrace = cell(nRuns, 2);
runTrainSeconds = zeros(nRuns, 2);
variants = {'local', 'shared'};
variantLabel = {'A', 'B'};
for run = 1:nRuns
    for v = 1:2
        seed = R.seedBase + 1000*(run-1) + (v-1);
        fprintf('\n--- Run %d/%d, Variant %s (%s reward), seed %d ---\n', run, nRuns, variantLabel{v}, variants{v}, seed);
        t0 = tic;
        L = train_q_learning(P, R, DATAopt, variants{v}, bounds, seed);
        runTrainSeconds(run, v) = toc(t0);
        runK(run,:,v) = L.K;
        runQ{run, v} = L.Q;
        runTrace{run, v} = L.trace;
        runMetrics{run, v} = evaluate_solution(L.K, P, DATAeval, false);
        fprintf('Learned beam vector (Variant %s): ', variantLabel{v}); fprintf('%d ', L.K);
        fprintf('(mean %.2f)\n', mean(L.K));
        fprintf('Evaluation: Tput %.4f Mbps, P5 SINR %.3f dB, JFI %.4f, OH %.3f %%, Interf %.3f dBm  [%.1f s]\n', ...
            runMetrics{run,v}.AvgEffTput_Mbps, runMetrics{run,v}.P5SINR_dB, runMetrics{run,v}.JFI, ...
            runMetrics{run,v}.AvgOverhead_percent, runMetrics{run,v}.AvgInterference_dBm, runTrainSeconds(run,v));
    end
end

% ------------------------------ pooled comparison (primary run = run 1) ----
allStructs = [refMetrics, {runMetrics{1,1}, runMetrics{1,2}}];
[FoM15, order15, mat15] = pool_fom(allStructs);

hdrRank = {'Rank','Configuration','PoolFoM','AvgEffTput_Mbps','P5SINR_dB','JFI','AvgOverhead_percent','AvgInterference_dBm'};
rowsRank = cell(15, 8);
for i = 1:15
    j = order15(i);
    rowsRank(i,:) = {i, names{j}, rnd(FoM15(j),4), rnd(mat15(j,1),4), rnd(mat15(j,2),4), ...
                     rnd(mat15(j,3),4), rnd(mat15(j,4),4), rnd(mat15(j,5),4)};
end
fprintf('\nEqual-weight FoM ranking over the pool of all 15 configurations (run 1):\n');
print_cells(hdrRank, rowsRank);

% Extended comparison (rows = metrics).
metricNames = {'Avg. SINR (dB)'; '5%-tile SINR (dB)'; 'Coverage (SINR > 3 dB) (%)'; ...
               'Avg. Effective Throughput (Mbps/user)'; '5%-tile Throughput (Mbps/user)'; ...
               'Median Throughput (Mbps/user)'; 'Jain Fairness Index of Throughput'; ...
               'Avg. Overhead (%)'; 'Avg. Interference (dBm)'};
hdrExt = [{'Metric'}, names];
rowsExt = cell(numel(metricNames), 16);
for i = 1:numel(metricNames), rowsExt{i,1} = metricNames{i}; end
for j = 1:15
    vec = metric_vec9(allStructs{j});
    for i = 1:9, rowsExt{i, j+1} = rnd(vec(i), 4); end
end

% Compact head-to-head table.
bestFixed = 0; bestVal = -inf;
FoM13 = pool_fom(refMetrics);
for kk = 1:9
    if FoM13(kk) > bestVal, bestVal = FoM13(kk); bestFixed = kk; end
end
cmpIdx = unique([5, bestFixed, 12, 13, 14, 15], 'stable');
hdrCmp = [{'Metric'}, names(cmpIdx)];
rowsCmp = cell(9, numel(cmpIdx)+1);
for i = 1:9
    rowsCmp{i,1} = metricNames{i};
    for c = 1:numel(cmpIdx), rowsCmp{i,c+1} = rowsExt{i, cmpIdx(c)+1}; end
end

% Robustness of the ranking to the pool definition.
poolDefs = { 'All 15 configurations',            1:15; ...
             '13 original + RL-A',                [1:13 14]; ...
             '13 original + RL-B',                [1:13 15]; ...
             'Head-to-head: NSGA-III, MOWOA, RL-A, RL-B', [12 13 14 15]; ...
             'Head-to-head + best fixed + Fixed 8',        unique([5 bestFixed 12 13 14 15]) };
hdrPool = {'Pool','Pool size','Configuration','PoolFoM','Rank in pool'};
rowsPool = {};
for pI = 1:size(poolDefs,1)
    idx = poolDefs{pI,2};
    [f, ord] = pool_fom(allStructs(idx));
    for t = [12 13 14 15]
        loc = find(idx == t, 1);
        if isempty(loc), continue; end
        rowsPool(end+1,:) = {poolDefs{pI,1}, numel(idx), names{t}, rnd(f(loc),4), find(ord == loc)}; %#ok<AGROW>
    end
end
fprintf('\nRanking robustness over different pools:\n');
print_cells(hdrPool, rowsPool);

% Per-sector beam counts.
hdrK = {'Sector','BS-Sector','Nominal load (UEs)','NSGA-III','MOWOA','RL-A','RL-B'};
rowsK = cell(P.numPairs + 1, 7);
for q = 1:P.numPairs
    [bs, sec] = pair_to_bssec(q, P);
    rowsK(q,:) = {q, sprintf('BS%d-S%d', bs, sec), P.sectorLoadProfile(q), K_NSGA(q), K_MOWOA(q), runK(1,q,1), runK(1,q,2)};
end
rowsK(end,:) = {'Mean', '', rnd(mean(P.sectorLoadProfile),2), rnd(mean(K_NSGA),2), rnd(mean(K_MOWOA),2), ...
                rnd(mean(runK(1,:,1)),2), rnd(mean(runK(1,:,2)),2)};

% Agreement between learned policies and the metaheuristic solutions.
agree = zeros(2, 2);
for v = 1:2
    agree(v,1) = sum(runK(1,:,v) == K_NSGA);
    agree(v,2) = sum(runK(1,:,v) == K_MOWOA);
end
fprintf('\nSectors with identical beam count (of %d): RL-A vs NSGA-III %d, vs MOWOA %d; RL-B vs NSGA-III %d, vs MOWOA %d\n', ...
    P.numPairs, agree(1,1), agree(1,2), agree(2,1), agree(2,2));
fprintf('Rank correlation (Spearman) of beam count with nominal load: NSGA-III %.3f, MOWOA %.3f, RL-A %.3f, RL-B %.3f\n', ...
    spearman(K_NSGA, P.sectorLoadProfile), spearman(K_MOWOA, P.sectorLoadProfile), ...
    spearman(runK(1,:,1), P.sectorLoadProfile), spearman(runK(1,:,2), P.sectorLoadProfile));

% Per-run summary (useful when nRuns > 1).
hdrRuns = {'Run','Variant','AvgEffTput_Mbps','P5SINR_dB','JFI','AvgOverhead_percent','AvgInterference_dBm','Mean K','Rank in 15-pool','Train time (s)'};
rowsRuns = {};
for run = 1:nRuns
    st = [refMetrics, {runMetrics{run,1}, runMetrics{run,2}}];
    [f, ord] = pool_fom(st);
    for v = 1:2
        m = runMetrics{run,v};
        rowsRuns(end+1,:) = {run, variantLabel{v}, rnd(m.AvgEffTput_Mbps,4), rnd(m.P5SINR_dB,4), rnd(m.JFI,4), ...
            rnd(m.AvgOverhead_percent,4), rnd(m.AvgInterference_dBm,4), rnd(mean(runK(run,:,v)),2), ...
            find(ord == 13+v), rnd(runTrainSeconds(run,v),1)}; %#ok<AGROW>
    end
end
fprintf('\nPer-run summary:\n'); print_cells(hdrRuns, rowsRuns);

% Setup table.
hdrSetup = {'Item','Setting'};
rowsSetup = {
    'Method', 'Tabular Q-learning, epsilon-greedy (adapted from Lee et al., Sensors 2024)';
    'Agents / actions', sprintf('%d independent agents (one per sector); %d actions (beam counts)', P.numPairs, P.numCandidates);
    'State', 'Single state per agent (static scenario)';
    'Bellman update', 'Q <- (1-alpha) Q + alpha [ r + gamma max Q ]';
    'Discount factor gamma', sprintf('%.2f', R.gamma);
    'Learning rate alpha', sprintf('max(%.2f, 1/n^%.1f)', R.alphaMin, R.alphaExp);
    'Exploration epsilon', sprintf('%.2f to %.2f, exponential decay over %.0f%% of the steps', R.epsStart, R.epsEnd, 100*R.epsDecayFrac);
    'Training budget', sprintf('%d joint evaluations on %d optimization snapshots (= NSGA-III / MOWOA)', R.nSteps, P.NsnapOpt);
    'Reward Variant A', 'Own-sector mean effective throughput (net of overhead), local';
    'Reward Variant B', 'Shared equal-weight mean of five normalized objectives, fixed bounds from homogeneous configurations';
    'Final policy', 'Greedy: argmax_a Q(sector, a)';
    'Evaluation data', sprintf('%d snapshots, seed %d (common to all configurations)', P.NsnapEval, P.seedEvalData);
    'Exploration seed', sprintf('%d (+1000 per run, +1 for Variant B)', R.seedBase);
    'Independent runs', sprintf('%d', nRuns)};

% ------------------------------ export tables ------------------------------
write_cell_word(hdrExt,  rowsExt,  fullfile(outDir, 'Table_R2P1_Extended_Comparison.doc'), 'Extended final evaluation including the RL baselines (run 1)');
write_cell_word(hdrCmp,  rowsCmp,  fullfile(outDir, 'Table_R2P1_Compact_Comparison.doc'),  'Head-to-head comparison: Fixed 8, best fixed, NSGA-III, MOWOA, RL-A, RL-B');
write_cell_word(hdrRank, rowsRank, fullfile(outDir, 'Table_R2P1_Pool15_FoM_Ranking.doc'),  'Equal-weight FoM ranking over 15 configurations');
write_cell_word(hdrPool, rowsPool, fullfile(outDir, 'Table_R2P1_Pool_Robustness.doc'),     'Ranking robustness over different pools');
write_cell_word(hdrK,    rowsK,    fullfile(outDir, 'Table_R2P1_Beam_Vectors.doc'),        'Selected beam count per sector');
write_cell_word(hdrRuns, rowsRuns, fullfile(outDir, 'Table_R2P1_Run_Summary.doc'),         'Per-run summary of the RL baselines');
write_cell_word(hdrSetup, rowsSetup, fullfile(outDir, 'Table_R2P1_RL_Setup.doc'),          'RL baseline setup');

% ------------------------------ figures ------------------------------------
try
    plot_learning_curves(runTrace{1,1}, runTrace{1,2}, R, outDir);
    plot_beam_vectors(K_NSGA, K_MOWOA, runK(1,:,1), runK(1,:,2), outDir);
catch ME
    warning('Figure generation failed: %s', ME.message);
end

% ------------------------------ store --------------------------------------
RES = struct();
RES.P = P; RES.R = R; RES.bounds = bounds;
RES.names = names; RES.refMetrics = refMetrics;
RES.runK = runK; RES.runMetrics = runMetrics; RES.runQ = runQ; RES.runTrace = runTrace;
RES.runTrainSeconds = runTrainSeconds;
RES.FoM15 = FoM15; RES.rowsRank = rowsRank; RES.rowsPool = rowsPool; RES.rowsRuns = rowsRuns;
RES.rowsExt = rowsExt; RES.rowsCmp = rowsCmp; RES.rowsK = rowsK;
save(fullfile(outDir, 'RL_BASELINE_R2P1_RESULTS.mat'), 'RES', '-v7');

fprintf('\nDone. All tables, figures, the .mat file and console_log.txt are in: %s\n', outDir);
end

% =========================================================================
% Q-learning agent training
% =========================================================================
function L = train_q_learning(P, R, DATAopt, rewardMode, bounds, seed)
nQ = P.numPairs; nA = P.numCandidates;
rng(seed, 'twister');
Q = zeros(nQ, nA);
cnt = zeros(nQ, nA);
trace = zeros(R.nSteps, 1);
nDecay = max(1, R.epsDecayFrac * R.nSteps);
reportEvery = max(1, floor(R.nSteps/10));
for t = 1:R.nSteps
    eps_t = max(R.epsEnd, R.epsStart * (R.epsEnd/R.epsStart)^((t-1)/nDecay));
    a = zeros(1, nQ);
    for q = 1:nQ
        if rand < eps_t
            a(q) = randi(nA);
        else
            untried = find(cnt(q,:) == 0);
            if ~isempty(untried)
                a(q) = untried(randi(numel(untried)));
            else
                best = find(Q(q,:) >= max(Q(q,:)) - 1e-12);
                a(q) = best(randi(numel(best)));
            end
        end
    end
    Kvec = P.beamCandidates(a);
    [m, ~, secTput] = evaluate_solution(Kvec, P, DATAopt, false);
    rShared = shared_reward(m, bounds);
    trace(t) = rShared;
    if strcmp(rewardMode, 'local')
        r = secTput(:)';
    else
        r = rShared * ones(1, nQ);
    end
    for q = 1:nQ
        tried = cnt(q,:) > 0;
        if any(tried), mq = max(Q(q,tried)); else, mq = 0; end
        cnt(q,a(q)) = cnt(q,a(q)) + 1;
        alpha = max(R.alphaMin, 1/cnt(q,a(q))^R.alphaExp);
        Q(q,a(q)) = (1-alpha)*Q(q,a(q)) + alpha*(r(q) + R.gamma*mq);
    end
    if mod(t, reportEvery) == 0
        fprintf('  step %5d/%d  eps=%.3f  mean shared reward (last %d steps) = %.4f\n', ...
            t, R.nSteps, eps_t, min(t,reportEvery), mean(trace(max(1,t-reportEvery+1):t)));
    end
end
[~, idx] = max(Q, [], 2);
L.K = P.beamCandidates(idx(:)');
L.Q = Q; L.cnt = cnt; L.trace = trace;
end

function r = shared_reward(m, bounds)
x = metric5(m);
benefit = [true true true false false];
nb = zeros(1,5);
for j = 1:5
    d = bounds.hi(j) - bounds.lo(j);
    if d < 1e-12
        nb(j) = 1;
    elseif benefit(j)
        nb(j) = (x(j) - bounds.lo(j)) / d;
    else
        nb(j) = (bounds.hi(j) - x(j)) / d;
    end
end
r = mean(nb);
end

function x = metric5(m)
x = [m.AvgEffTput_Mbps, m.P5SINR_dB, m.JFI, m.AvgOverhead_percent, m.AvgInterference_dBm];
end

function v = metric_vec9(M)
v = [M.AvgSINR_dB; M.P5SINR_dB; M.Coverage_pct; M.AvgEffTput_Mbps; M.P5Tput_Mbps; ...
     M.MedianTput_Mbps; M.JFI; M.AvgOverhead_percent; M.AvgInterference_dBm];
end

function [FoM, order, candMat] = pool_fom(structs)
n = numel(structs);
candMat = zeros(n, 8);
for k = 1:n
    m = structs{k};
    candMat(k,:) = [m.AvgEffTput_Mbps, m.P5SINR_dB, m.JFI, m.AvgOverhead_percent, ...
                    m.AvgInterference_dBm, m.Coverage_pct, m.AvgSINR_dB, m.P5Tput_Mbps];
end
FoM = compute_fom_equal_weights(candMat);
[~, order] = sort(FoM, 'descend');
end

function rho = spearman(x, y)
rx = tiedrank_local(x(:)); ry = tiedrank_local(y(:));
c = corrcoef(rx, ry);
if numel(c) == 1, rho = NaN; else, rho = c(1,2); end
end

function r = tiedrank_local(x)
[xs, ord] = sort(x);
r = zeros(size(x));
i = 1; n = numel(x);
while i <= n
    j = i;
    while j < n && xs(j+1) == xs(i), j = j + 1; end
    r(ord(i:j)) = (i + j)/2;
    i = j + 1;
end
end

function print_cells(hdr, rows)
fprintf('%s\n', strjoin(hdr, ' | '));
for i = 1:size(rows,1)
    parts = cell(1, size(rows,2));
    for c = 1:size(rows,2)
        v = rows{i,c};
        if ischar(v), parts{c} = v;
        elseif isnumeric(v) && isscalar(v)
            if v == round(v), parts{c} = sprintf('%d', v); else, parts{c} = sprintf('%.4f', v); end
        else, parts{c} = ''; end
    end
    fprintf('%s\n', strjoin(parts, ' | '));
end
end

function plot_learning_curves(trA, trB, R, outDir)
w = max(1, min(200, floor(numel(trA)/10)));
smooth = @(x) conv(x(:), ones(w,1)/w, 'valid');
f = figure('Visible', 'off', 'Color', 'w');
plot(w:numel(trA), smooth(trA), 'LineWidth', 1.5); hold on;
plot(w:numel(trB), smooth(trB), 'LineWidth', 1.5);
xline_compat(R.epsDecayFrac * R.nSteps);
grid on; xlabel('Training step (joint evaluation)'); ylabel('Shared reward (equal-weight normalized objectives)');
legend({'Variant A (local throughput)', 'Variant B (shared 5-objective)', 'End of epsilon decay'}, 'Location', 'southeast');
title('Q-learning training curves (moving average)');
save_png_compat(f, fullfile(outDir, 'Fig_R2P1_Learning_Curves.png'));
close(f);
end

function xline_compat(x)
yl = ylim;
plot([x x], yl, 'k--');
end

function plot_beam_vectors(Kn, Km, Ka, Kb, outDir)
f = figure('Visible', 'off', 'Color', 'w');
bar([Kn(:), Km(:), Ka(:), Kb(:)]);
grid on; xlabel('Sector index'); ylabel('Beams per sector');
legend({'NSGA-III', 'MOWOA', 'RL-A', 'RL-B'}, 'Location', 'northeastoutside');
title('Selected beam count per sector');
save_png_compat(f, fullfile(outDir, 'Fig_R2P1_Beam_Vectors.png'));
close(f);
end

function write_cell_word(hdr, rows, fname, tableTitle)
% Export a header cell array and a cell matrix of rows to a Word-readable .doc (HTML).
fid = fopen(fname, 'w');
if fid == -1
    warning('write_cell_word: cannot open %s', fname);
    return;
end
fprintf(fid, '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">\n');
fprintf(fid, '<head><meta charset="UTF-8"><title>%s</title>\n', tableTitle);
fprintf(fid, ['<style> body{font-family:Calibri,Arial,sans-serif;} table{border-collapse:collapse;width:100%%;} ' ...
    'th,td{border:1px solid #444444;padding:4px 6px;text-align:center;font-size:9pt;} ' ...
    'th{background-color:#D9E1F2;font-weight:bold;} h1{font-size:14pt;color:#1F4E78;} </style>\n']);
fprintf(fid, '</head><body>\n<h1>%s</h1>\n<table>\n<tr>', tableTitle);
for c = 1:numel(hdr)
    fprintf(fid, '<th>%s</th>', strrep(hdr{c}, '_', ' '));
end
fprintf(fid, '</tr>\n');
for r = 1:size(rows,1)
    fprintf(fid, '<tr>');
    for c = 1:size(rows,2)
        v = rows{r,c};
        if ischar(v)
            s = v;
        elseif isnumeric(v) && isscalar(v)
            if v == round(v), s = sprintf('%d', v); else, s = sprintf('%.4f', v); end
        else
            s = '';
        end
        fprintf(fid, '<td>%s</td>', s);
    end
    fprintf(fid, '</tr>\n');
end
fprintf(fid, '</table>\n</body></html>');
fclose(fid);
end

function y = rnd(x, d)
% Portable rounding to d decimals (also works in Octave).
y = round(x * 10^d) / 10^d;
end

function P = nominal_params()
P.numBS = 7;
P.numSec = 3;
P.numPairs = P.numBS * P.numSec;
P.UEsPerSec = 20;
P.useNonUniformLoad = true;
P.minUEsPerSec = 8;
P.maxUEsPerSec = 35;
P.loadJitterUE = 3;
P.sectorLoadProfile = [34 20 10, 14 28 12, 22 9 32, 11 24 18, 30 13 21, 16 27 8, 25 15 29];
P.NsnapOpt = 25;
P.NsnapEval = 200;
P.BW_Hz = 100e6;
P.f_c_Hz = 28e9;
P.Pt_dBm = 33;
P.NF_dB = 9;
P.antennaGain_dBi = 15;
P.frontBackLimit_dB = 30;
P.sectorSpan_deg = 120;
P.sectorRadius_m = 150;
P.mu = 3;
P.nSym_slot = 14;
P.nSym_SSB = 4;
P.T_ssb_period_ms = 20;
P.T_csi_period_ms = 5;
P.OH_cap = 0.50;
P.beamComplexityPenaltyMax = 0.10;
P.beamComplexityPenaltyPower = 1.0;
P.rho_active = 0.70;
P.rho_idle = 0.05;
P.Nref = 30;
P.eta_overlap = 0.50;
P.pCorrectAt8 = 0.90;
P.pCorrectSlope = 0.012;
P.pCorrectMin = 0.65;
P.pCorrectMax = 0.96;
P.sigmaSh_dB = 4;
P.coverageThreshold_dB = 3.0;
P.bsPos = [500 500; 800 500; 200 500; 650 760; 650 240; 350 760; 350 240];
P.beamCandidates = [2 3 4 6 8 10 15 20 24];
P.numCandidates = numel(P.beamCandidates);
P.seedEvalData = 51001;
P.Pt_W = 10^((P.Pt_dBm - 30)/10);
P.noise_dBm = -174 + 10*log10(P.BW_Hz) + P.NF_dB;
P.noise_W = 10^((P.noise_dBm - 30)/10);
P.T_slot_ms = 1/(2^P.mu);
P.Tsym_ms = P.T_slot_ms/P.nSym_slot;
P.T_SSB_ms = P.nSym_SSB*P.Tsym_ms;
P.OH_CSI_reference = P.Tsym_ms/P.T_csi_period_ms;
end

% =========================================================================
% Model functions copied unchanged from nsga3_mowoa_beam_archive_R2P2.m
% (evaluate_solution only gains the optional third output secTput)
% =========================================================================

function DATA = generate_mc_data(P, Nsnap, seedValue)
rng(seedValue, 'twister');
DATA = repmat(struct(), Nsnap, 1);

for snap = 1:Nsnap
    sectorLoad = generate_sector_loads(P);
    N = sum(sectorLoad);
    user = zeros(N, 5); % bs, sector, pair, x, y
    row = 0;

    % UEs are generated inside each active sector. In the corrected version,
    % sector loads are intentionally non-uniform to avoid artificial network
    % symmetry and to make sector-dependent beam selection meaningful.
    for bs = 1:P.numBS
        sx = P.bsPos(bs,1);
        sy = P.bsPos(bs,2);
        for sec = 1:P.numSec
            pair = (bs-1)*P.numSec + sec;
            Nu = sectorLoad(pair);
            az0 = (sec-1) * P.sectorSpan_deg;
            az1 = sec * P.sectorSpan_deg;
            r = sqrt(rand(Nu,1)) * P.sectorRadius_m;
            az = az0 + rand(Nu,1) * (az1 - az0);
            x = sx + r .* cosd(az);
            y = sy + r .* sind(az);
            idx = row + (1:Nu);
            user(idx,:) = [bs*ones(Nu,1), sec*ones(Nu,1), ...
                           pair*ones(Nu,1), x, y];
            row = row + Nu;
        end
    end

    x = user(:,4);
    y = user(:,5);

    localAng = zeros(N, P.numPairs);
    PL_dB = zeros(N, P.numPairs);

    for q = 1:P.numPairs
        [bsq, secq] = pair_to_bssec(q, P);
        xb = P.bsPos(bsq,1);
        yb = P.bsPos(bsq,2);
        th = atan2d(y - yb, x - xb);
        th(th < 0) = th(th < 0) + 360;

        % Corrected interference-angle model:
        % Do NOT clamp out-of-sector directions to 120-eps. Instead, keep
        % the wrapped local angle in [0,360). The antenna pattern then uses
        % wrap180(localAngle - beamCenter), which naturally gives low gain
        % for users outside the sector main angular region.
        thLocal = th - (secq-1)*P.sectorSpan_deg;
        thLocal = mod(thLocal, 360);
        localAng(:,q) = thLocal;

        d = hypot(x - xb, y - yb);
        PL_dB(:,q) = path_loss_uma_simple(d, P.f_c_Hz) + P.sigmaSh_dB*randn(N,1);
    end

    rhoSector = P.rho_idle + (P.rho_active - P.rho_idle) .* min(1, sectorLoad(:)/P.Nref);

    DATA(snap).snapshot = snap;
    DATA(snap).sectorLoad = sectorLoad(:);
    DATA(snap).rhoSector = rhoSector(:);
    DATA(snap).bsIdx = user(:,1);
    DATA(snap).secIdx = user(:,2);
    DATA(snap).pairIdx = user(:,3);
    DATA(snap).x_m = x;
    DATA(snap).y_m = y;
    DATA(snap).localAng = localAng;
    DATA(snap).PL_dB = PL_dB;
    DATA(snap).randCorrect = rand(N,1);
    DATA(snap).randNeighbor = rand(N,1);
    DATA(snap).randInterfBeam = rand(N, P.numPairs);
end
end

function [metrics, rows, secTput] = evaluate_solution(Kvec, P, DATA, returnRows)
% Identical to the model used in all earlier rounds; the only addition is the
% third output secTput (mean effective throughput of the users of each sector),
% which is needed by the local reward of RL Variant A. Metrics are unchanged.
if nargin < 4
    returnRows = false;
end

Kvec = Kvec(:)';
Nsnap = numel(DATA);
Ntot = 0;
for ss = 1:Nsnap
    Ntot = Ntot + numel(DATA(ss).pairIdx);
end

allSinr_dB = zeros(Ntot,1);
allTput = zeros(Ntot,1);
allInterf_W = zeros(Ntot,1);
allOH = zeros(Ntot,1);

if returnRows
    allSnap = zeros(Ntot,1);
    allBS = zeros(Ntot,1);
    allSec = zeros(Ntot,1);
    allPair = zeros(Ntot,1);
    allK = zeros(Ntot,1);
    allLoad = zeros(Ntot,1);
    allPcorrect = zeros(Ntot,1);
    allX = zeros(Ntot,1);
    allY = zeros(Ntot,1);
end

sectorOH = compute_sector_overheads(Kvec, P);
ptr = 0;
secSum = zeros(P.numPairs,1);
secCnt = zeros(P.numPairs,1);

for ss = 1:Nsnap
    D = DATA(ss);
    N = numel(D.pairIdx);
    pairIdx = D.pairIdx(:);
    rowIdx = (1:N)';

    Kserv = Kvec(pairIdx);
    Kserv = Kserv(:);
    HPBWserv = P.sectorSpan_deg ./ Kserv;

    indServ = sub2ind([N P.numPairs], rowIdx, pairIdx);
    thServ = D.localAng(indServ);

    % Serving users are generated inside their serving sector, but we still
    % clamp numerically to [0,120) for robust beam-index calculation.
    thServForIndex = thServ;
    thServForIndex(thServForIndex < 0) = 0;
    thServForIndex(thServForIndex >= P.sectorSpan_deg) = P.sectorSpan_deg - eps;

    PLserv = D.PL_dB(indServ);

    % Uniform sector codebook: center angles are (0.5:1:K-0.5)*HPBW.
    bestBeamIdx = floor(thServForIndex ./ HPBWserv) + 1;
    bestBeamIdx = max(bestBeamIdx, 1);
    bestBeamIdx = min(bestBeamIdx, Kserv);

    chosenBeamIdx = bestBeamIdx;

    % Corrected beam-selection model: p_correct is K-dependent. Narrower beams
    % are more sensitive to angular error and therefore have a lower chance of
    % selecting the exact best beam.
    pCorrectUser = beam_correct_probability(Kserv, P);
    miss = D.randCorrect(:) > pCorrectUser;
    if any(miss)
        onlyLeft = miss & (bestBeamIdx == Kserv) & (Kserv > 1);
        onlyRight = miss & (bestBeamIdx == 1) & (Kserv > 1);
        middle = miss & (bestBeamIdx > 1) & (bestBeamIdx < Kserv);

        chosenBeamIdx(onlyLeft) = bestBeamIdx(onlyLeft) - 1;
        chosenBeamIdx(onlyRight) = bestBeamIdx(onlyRight) + 1;

        midIdx = find(middle);
        if ~isempty(midIdx)
            chosenBeamIdx(midIdx) = bestBeamIdx(midIdx) - 1;
            chooseRight = D.randNeighbor(midIdx) >= 0.5;
            chosenBeamIdx(midIdx(chooseRight)) = bestBeamIdx(midIdx(chooseRight)) + 1;
        end
    end

    beamCenterServ = (chosenBeamIdx - 0.5) .* HPBWserv;
    deltaServ = abs(wrap180_local(thServ - beamCenterServ));
    Gserv = beam_gain(deltaServ, HPBWserv, P.antennaGain_dBi, P.frontBackLimit_dB);
    g_eff = 10.^((Gserv - PLserv)/10);

    % Load-aware inter-sector interference from all non-serving sectors.
    % Each interfering sector has its own rho based on its current snapshot load.
    I_W = zeros(N,1);
    for q = 1:P.numPairs
        active = pairIdx ~= q;
        if ~any(active)
            continue;
        end
        Kq = Kvec(q);
        HPBWq = P.sectorSpan_deg / Kq;
        intBeamIdx = floor(D.randInterfBeam(:,q) * Kq) + 1;
        intBeamIdx = max(intBeamIdx, 1);
        intBeamIdx = min(intBeamIdx, Kq);
        beamCenterI = (intBeamIdx - 0.5) * HPBWq;

        % Corrected: localAng can be outside [0,120). The wrapped angular
        % distance to the selected interfering beam center is used directly.
        deltaI = abs(wrap180_local(D.localAng(:,q) - beamCenterI));
        GI = beam_gain(deltaI, HPBWq, P.antennaGain_dBi, P.frontBackLimit_dB);
        Iterm = P.eta_overlap * D.rhoSector(q) * 10.^((P.Pt_dBm + GI - D.PL_dB(:,q) - 30)/10);
        I_W(active) = I_W(active) + Iterm(active);
    end

    sinrLinear = P.Pt_W * g_eff ./ (P.noise_W + I_W);
    sinr_dB = 10*log10(max(sinrLinear, realmin));
    OHuser = sectorOH(pairIdx);

    % No WF: equal resource share among the users currently assigned to the
    % same sector. With non-uniform load, bandwidth share is sector-dependent.
    loadUser = D.sectorLoad(pairIdx);
    loadUser = max(loadUser(:), 1);
    tput = (P.BW_Hz ./ loadUser) .* log2(1 + sinrLinear) / 1e6 .* (1 - OHuser);

    idxOut = ptr + (1:N);
    allSinr_dB(idxOut) = sinr_dB;
    allTput(idxOut) = tput;
    secSum = secSum + accumarray(pairIdx, tput, [P.numPairs 1]);
    secCnt = secCnt + accumarray(pairIdx, ones(N,1), [P.numPairs 1]);
    allInterf_W(idxOut) = I_W;
    allOH(idxOut) = OHuser;

    if returnRows
        allSnap(idxOut) = ss;
        allBS(idxOut) = D.bsIdx;
        allSec(idxOut) = D.secIdx;
        allPair(idxOut) = pairIdx;
        allK(idxOut) = Kserv;
        allLoad(idxOut) = loadUser;
        allPcorrect(idxOut) = pCorrectUser;
        allX(idxOut) = D.x_m;
        allY(idxOut) = D.y_m;
    end

    ptr = ptr + N;
end

metrics = struct();
secTput = secSum ./ max(secCnt, 1);
metrics.AvgSINR_dB = mean(allSinr_dB);
metrics.P5SINR_dB = prctile(allSinr_dB, 5);
metrics.Coverage_pct = 100 * mean(allSinr_dB > P.coverageThreshold_dB);
metrics.AvgEffTput_Mbps = mean(allTput);
metrics.JFI = jain_fairness(allTput);
metrics.AvgOverhead = mean(allOH);
metrics.AvgOverhead_percent = 100 * metrics.AvgOverhead;
metrics.AvgInterference_W = mean(allInterf_W);
metrics.AvgInterference_dBm = 10*log10(max(metrics.AvgInterference_W, realmin)*1000);
metrics.P5Tput_Mbps = prctile(allTput, 5);
metrics.MedianTput_Mbps = median(allTput);

if returnRows
    interf_dBm = 10*log10(max(allInterf_W, realmin)*1000);
    rows = table(allSnap, allBS, allSec, allPair, allK, allLoad, allPcorrect, allX, allY, ...
        allSinr_dB, allTput, allOH, 100*allOH, allInterf_W, interf_dBm, ...
        'VariableNames', {'snapshot','bs','sector','pair','numBeams','sectorLoad','pCorrectBeam','x_m','y_m', ...
        'sinr_dB','tput_Mbps','overhead','overhead_percent','interference_W','interference_dBm'});
else
    rows = [];
end
end

function Kvec = heuristic_beam_vector(P, mode)
% HEURISTIC_BEAM_VECTOR  Simple closed-form, load-aware beam-count rule (no optimization).
% The NOMINAL sector load profile is linearly mapped onto [Kmin, Kmax] and
% snapped to the nearest candidate beam count.
%   'proportional': higher load -> more beams.
%   'inverse'     : higher load -> fewer beams.
nom = P.sectorLoadProfile(:)';
lo = min(nom); hi = max(nom);
Kmin = min(P.beamCandidates); Kmax = max(P.beamCandidates);
t = (nom - lo) / (hi - lo);
if strcmp(mode, 'inverse')
    t = 1 - t;
end
target = Kmin + t * (Kmax - Kmin);
Kvec = zeros(1, numel(target));
for q = 1:numel(target)
    [~, j] = min(abs(P.beamCandidates - target(q)));
    Kvec(q) = P.beamCandidates(j);
end
end

function sectorOH = compute_sector_overheads(Kvec, P)
Kvec = Kvec(:)';

% Corrected overhead model:
% 1) SSB sweeping overhead grows with K.
% 2) CSI/beam refinement overhead also grows with K, instead of being fixed.
% 3) A normalized beam-management complexity penalty is included to represent
%    search latency, measurement/reporting burden, and control complexity.
OH_SSB = Kvec * P.T_SSB_ms / P.T_ssb_period_ms;
OH_CSI = Kvec * P.Tsym_ms / P.T_csi_period_ms;

Kmin = min(P.beamCandidates);
Kmax = max(P.beamCandidates);
if Kmax > Kmin
    Knorm = (Kvec - Kmin) / (Kmax - Kmin);
else
    Knorm = zeros(size(Kvec));
end
OH_complexity = P.beamComplexityPenaltyMax * (Knorm .^ P.beamComplexityPenaltyPower);

sectorOH = min(OH_SSB + OH_CSI + OH_complexity, P.OH_cap);
sectorOH = sectorOH(:);
end

function [FoM, normMetrics] = compute_fom_equal_weights(metrics)
% metrics columns:
% 1 AvgEffTput_Mbps        benefit
% 2 P5SINR_dB              benefit
% 3 JFI                    benefit
% 4 AvgOverhead_percent    cost
% 5 AvgInterference_dBm    cost
% 6 Coverage_pct           reporting only
% 7 AvgSINR_dB             reporting only
% 8 P5Tput_Mbps            reporting only

X = metrics(:,1:5);
benefit = [true true true false false];
normMetrics = zeros(size(X));

for j = 1:5
    x = X(:,j);
    xmin = min(x);
    xmax = max(x);
    if abs(xmax - xmin) < 1e-12
        normMetrics(:,j) = ones(size(x));
    else
        if benefit(j)
            normMetrics(:,j) = (x - xmin) / (xmax - xmin);
        else
            normMetrics(:,j) = (xmax - x) / (xmax - xmin);
        end
    end
end

weights = ones(1,5)/5;
FoM = normMetrics * weights(:);
end

function loadVec = generate_sector_loads(P)
if isfield(P, 'useNonUniformLoad') && P.useNonUniformLoad
    loadVec = P.sectorLoadProfile(:);
    jitter = round((2*rand(P.numPairs,1) - 1) * P.loadJitterUE);
    loadVec = loadVec + jitter;
    loadVec = max(P.minUEsPerSec, min(P.maxUEsPerSec, loadVec));
else
    loadVec = P.UEsPerSec * ones(P.numPairs,1);
end
loadVec = round(loadVec(:));
end

function [bs, sec] = pair_to_bssec(pair, P)
bs = floor((pair-1)/P.numSec) + 1;
sec = mod(pair-1, P.numSec) + 1;
end

function pCorr = beam_correct_probability(K, P)
% K-dependent beam-selection probability. The reference is pCorrectAt8 at
% K=8. Larger K means narrower beams and a higher probability of beam-index
% error; smaller K means wider beams and a more robust selection.
pCorr = P.pCorrectAt8 - P.pCorrectSlope * (K - 8);
pCorr = max(P.pCorrectMin, min(P.pCorrectMax, pCorr));
end

function PLdB = path_loss_uma_simple(d_m, f_Hz)
% Close, simple UMa-like path-loss expression retained from the original code.
% If your manuscript states the full 3GPP TR 38.901 UMa LOS/NLOS model,
% replace this function with the exact TR 38.901 implementation.
f_GHz = f_Hz/1e9;
d_m = max(d_m, 1);
PLdB = 32.4 + 21*log10(d_m) + 20*log10(f_GHz);
end

function G = beam_gain(delta, HPBW, Gmax, Am)
G = Gmax - min(12*(delta./HPBW).^2, Am);
end

function ang = wrap180_local(ang)
ang = mod(ang + 180, 360) - 180;
end

function J = jain_fairness(x)
x = x(:);
x(~isfinite(x)) = 0;
den = numel(x)*sum(x.^2);
if den <= 0
    J = 0;
else
    J = (sum(x)^2)/den;
end
end

function save_png_compat(figHandle, fname)
set(figHandle, 'PaperPositionMode', 'auto');
print(figHandle, fname, '-dpng', '-r300');
end
