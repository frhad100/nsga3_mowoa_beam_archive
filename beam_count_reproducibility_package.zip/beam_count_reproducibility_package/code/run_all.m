function run_all(steps)
% RUN_ALL  Runs the scripts of this package in the order of the manuscript. It only calls the
% other files of this folder and does not change anything inside them.
%
% USAGE   run_all            % all steps
%         run_all(1)         % one step only
%         run_all([3 4])     % selected steps
%
%   Step 1  nsga3_mowoa_beam_archive_R2P2        reference run, Figs. 1-4
%   Step 2  rl_baseline_R2P1 + plot_rl_curves_R2P1  Q-learning baseline, Table 7, Fig. 5
%   Step 3  sensitivity_layer1_R2P4              Table 5
%   Step 4  nsga3_mowoa_beam_archive_R2P4_L2(0)  re-optimization, Table 6
%   Step 5  multiseed_R2P3(20)                   20 runs and statistics, Tables 8-12, Fig. 6
%
% All output folders are created inside the folder  results_run_all  of the current directory.
% Step 5 depends on no other step. Tables 3 and 4 and Section 7.E are produced by
% ../analysis/reproduce_20run_summary.py from the CSV files in ../data.
if nargin < 1 || isempty(steps), steps = 1:5; end
codeDir = fileparts(mfilename('fullpath'));
addpath(codeDir);
outRoot = fullfile(pwd, 'results_run_all');
if ~exist(outRoot, 'dir'), mkdir(outRoot); end
startDir = pwd;
cleanupObj = onCleanup(@() cd(startDir));
cd(outRoot);
for s = steps(:)'
    t0 = tic;
    fprintf('\n##### run_all: step %d started %s #####\n', s, datestr(now, 'yyyy-mm-dd HH:MM:SS'));
    switch s
        case 1
            nsga3_mowoa_beam_archive_R2P2();
        case 2
            rl_baseline_R2P1();
            plot_rl_curves_R2P1();
        case 3
            sensitivity_layer1_R2P4();
        case 4
            nsga3_mowoa_beam_archive_R2P4_L2(0);
        case 5
            multiseed_R2P3(20);
        otherwise
            error('run_all: unknown step %d (valid steps are 1 to 5).', s);
    end
    fprintf('##### run_all: step %d finished after %.1f minutes #####\n', s, toc(t0) / 60);
end
end
