function RES = sensitivity_layer1_R2P4(nEvalSnap)
% SENSITIVITY_LAYER1_R2P4
% -------------------------------------------------------------------------
% Round-2, Point 4 (Layer 1): sensitivity of the final comparison to the
% phenomenological simulation assumptions.
%
% The beam-count vectors selected by NSGA-III and MOWOA under the NOMINAL
% parameters (Table 2 of the manuscript) are NOT re-optimized. For every
% scenario one (or, for the two "combined" scenarios, several) model
% parameters are changed, a fresh 200-snapshot evaluation dataset is
% generated with the SAME seed as the nominal evaluation (common random
% numbers), and the following 13 configurations are re-evaluated:
%     9 homogeneous beam counts (2 3 4 6 8 10 15 20 24),
%     2 load-aware heuristics (load-proportional, inverse-load),
%     NSGA-III FoM-best vector, MOWOA FoM-best vector.
% They are ranked with the same equal-weight Figure of Merit applied once to
% the pool of the 13 configurations (pool-normalized, as in Section 6.D/7.E).
%
% Because the pool is re-normalized in every scenario, FoM VALUES are only
% comparable within a scenario. RANKS and within-scenario margins are the
% quantities to compare across scenarios.
%
% Note: the homogeneous baselines are all evaluated in each scenario (so the
% best homogeneous configuration is implicitly "re-selected" per scenario),
% whereas the optimized vectors stay fixed. This test is therefore
% conservative with respect to the proposed method.
%
% How to run (about a few minutes; no optimization is performed):
%     RES = sensitivity_layer1_R2P4;
%
% The nominal scenario must reproduce Table 3 / Table 4 of the manuscript
% (Avg. throughput: Fixed8 27.9646, Fixed10 28.7409, Fixed15 28.9059,
%  Fixed24 26.8127, NSGA-III 28.2430, MOWOA 27.8439). A warning is printed if
% it does not.
% -------------------------------------------------------------------------
if nargin < 1
    nEvalSnap = 200;
end

outDir = fullfile(pwd, 'sensitivity_R2P4_outputs');
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

P0 = nominal_params();
P0.NsnapEval = nEvalSnap;

% Beam-count vectors selected under the nominal parameters (manuscript, Section 7.B).
K_NSGA  = [8 15 20 8 10 15 8 24 15 15 8 10 10 24 8 8 6 24 15 8 8];
K_MOWOA = [6 10 10 8 10 15 10 15 10 15 8 8 8 24 6 4 4 20 10 10 6];

% Heuristics are defined from the NOMINAL load profile (kept fixed in all scenarios).
K_HeurProp = heuristic_beam_vector(P0, 'proportional');
K_HeurInv  = heuristic_beam_vector(P0, 'inverse');

fixedList = P0.beamCandidates;
cfgNames = cell(1, numel(fixedList) + 4);
cfgK = cell(1, numel(fixedList) + 4);
for k = 1:numel(fixedList)
    cfgNames{k} = sprintf('Fixed %d', fixedList(k));
    cfgK{k} = fixedList(k) * ones(1, P0.numPairs);
end
nF = numel(fixedList);
cfgNames{nF+1} = 'Load-prop heuristic';   cfgK{nF+1} = K_HeurProp;
cfgNames{nF+2} = 'Inverse-load heuristic'; cfgK{nF+2} = K_HeurInv;
cfgNames{nF+3} = 'NSGA-III';              cfgK{nF+3} = K_NSGA;
cfgNames{nF+4} = 'MOWOA';                 cfgK{nF+4} = K_MOWOA;
nC = numel(cfgK);
idxHom = 1:nF; idxNSGA = nF+3; idxMOWOA = nF+4; idxFix8 = find(fixedList == 8);

scen = define_scenarios();
nS = numel(scen);

MetricsAll = zeros(nS, nC, 8);   % [Tput P5SINR JFI OH% Interf Cov AvgSINR P5Tput]
MedianTput = zeros(nS, nC);
FoMAll = zeros(nS, nC);
RankAll = zeros(nS, nC);

fprintf('\n=== Round-2 Point 4, Layer 1: %d scenarios x %d configurations (no re-optimization) ===\n', nS, nC);
tAll = tic;
for s = 1:nS
    P = apply_scenario(P0, scen{s}{3});
    DATA = generate_mc_data(P, P.NsnapEval, P.seedEvalData);
    for c = 1:nC
        m = evaluate_solution(cfgK{c}, P, DATA, false);
        MetricsAll(s,c,:) = [m.AvgEffTput_Mbps, m.P5SINR_dB, m.JFI, m.AvgOverhead_percent, ...
                             m.AvgInterference_dBm, m.Coverage_pct, m.AvgSINR_dB, m.P5Tput_Mbps];
        MedianTput(s,c) = m.MedianTput_Mbps;
    end
    FoMAll(s,:) = compute_fom_equal_weights(squeeze(MetricsAll(s,:,:)))';
    [~, ord] = sort(FoMAll(s,:), 'descend');
    RankAll(s, ord) = 1:nC;
    fprintf('[%2d/%2d] %-12s %-28s NSGA-III rank %2d | MOWOA rank %2d | best: %s   (%.0f s)\n', ...
        s, nS, scen{s}{1}, scen{s}{2}, RankAll(s,idxNSGA), RankAll(s,idxMOWOA), cfgNames{ord(1)}, toc(tAll));
end

% ---- reproduction check of the nominal scenario (only with the full 200-snapshot dataset)
if nEvalSnap == 200
    ref = [27.9646 26.8127 28.7409 28.9059 28.2430 27.8439];
    got = [MetricsAll(1, idxFix8, 1), MetricsAll(1, nF, 1), MetricsAll(1, fixedList==10, 1), ...
           MetricsAll(1, fixedList==15, 1), MetricsAll(1, idxNSGA, 1), MetricsAll(1, idxMOWOA, 1)];
    if any(abs(ref - got) > 5e-4)
        warning(['Nominal reproduction check FAILED (avg. throughput differs from Table 3/4). ' ...
                 'Do not use these results until this is resolved.']);
        disp([ref; got]);
    else
        fprintf('\nNominal reproduction check passed (matches Tables 3 and 4).\n');
    end
end

% ---- summary measures per scenario
dFoM_NSGA = zeros(nS,1); dFoM_MOW = zeros(nS,1); dTput_NSGA = zeros(nS,1);
dJFI_NSGA = zeros(nS,1); dMed_NSGA = zeros(nS,1); dFoM_NSGA_F8 = zeros(nS,1);
bestHomName = cell(nS,1); bestName = cell(nS,1);
summaryRows = cell(nS, 14);
for s = 1:nS
    [fb, jb] = max(FoMAll(s, idxHom));
    bestHomName{s} = cfgNames{jb};
    [~, jt] = max(FoMAll(s,:));
    bestName{s} = cfgNames{jt};
    dFoM_NSGA(s) = FoMAll(s,idxNSGA) - fb;
    dFoM_MOW(s)  = FoMAll(s,idxMOWOA) - fb;
    dFoM_NSGA_F8(s) = FoMAll(s,idxNSGA) - FoMAll(s,idxFix8);
    dTput_NSGA(s) = 100 * (MetricsAll(s,idxNSGA,1) - max(MetricsAll(s,idxHom,1))) / max(MetricsAll(s,idxHom,1));
    dJFI_NSGA(s)  = MetricsAll(s,idxNSGA,3) - max(MetricsAll(s,idxHom,3));
    dMed_NSGA(s)  = MedianTput(s,idxNSGA) - max(MedianTput(s,idxHom));
    summaryRows(s,:) = {s, scen{s}{1}, scen{s}{2}, RankAll(s,idxNSGA), RankAll(s,idxMOWOA), bestName{s}, ...
        rnd(FoMAll(s,idxNSGA), 4), rnd(FoMAll(s,idxMOWOA), 4), bestHomName{s}, ...
        rnd(dFoM_NSGA(s), 4), rnd(dFoM_MOW(s), 4), rnd(dFoM_NSGA_F8(s), 4), ...
        rnd(dTput_NSGA(s), 2), rnd(dJFI_NSGA(s), 4)};
end
summaryHdr = {'ID','Group','Scenario','NSGA-III rank','MOWOA rank','Top configuration', ...
    'FoM NSGA-III','FoM MOWOA','Best homogeneous','dFoM NSGA-III vs best homog.', ...
    'dFoM MOWOA vs best homog.','dFoM NSGA-III vs Fixed 8','dAvgTput NSGA-III vs best homog. (%)', ...
    'dJFI NSGA-III vs best homog.'};

fomRows = cell(nS, nC + 2);
for s = 1:nS
    fomRows(s,1:2) = {s, scen{s}{2}};
    for c = 1:nC
        fomRows{s, 2 + c} = rnd(FoMAll(s,c), 4);
    end
end
fomHdr = [{'ID','Scenario'}, cfgNames];

rankRows = cell(nS, nC + 2);
for s = 1:nS
    rankRows(s,1:2) = {s, scen{s}{2}};
    for c = 1:nC
        rankRows{s, 2 + c} = RankAll(s,c);
    end
end

% ---- aggregate statements (excluding the nominal scenario, s = 1)
rs = 2:nS;
fprintf('\n================ AGGREGATE OVER %d PERTURBED SCENARIOS ================\n', numel(rs));
fprintf('NSGA-III rank 1            : %d scenarios\n', sum(RankAll(rs,idxNSGA) == 1));
fprintf('NSGA-III rank <= 2         : %d scenarios\n', sum(RankAll(rs,idxNSGA) <= 2));
fprintf('NSGA-III rank <= 3         : %d scenarios\n', sum(RankAll(rs,idxNSGA) <= 3));
fprintf('MOWOA rank 1               : %d scenarios\n', sum(RankAll(rs,idxMOWOA) == 1));
fprintf('NSGA-III or MOWOA is #1    : %d scenarios\n', sum(RankAll(rs,idxNSGA) == 1 | RankAll(rs,idxMOWOA) == 1));
fprintf('NSGA-III or MOWOA in top 3 : %d scenarios\n', sum(RankAll(rs,idxNSGA) <= 3 | RankAll(rs,idxMOWOA) <= 3));
fprintf('NSGA-III FoM > best homog. : %d scenarios\n', sum(dFoM_NSGA(rs) > 0));
fprintf('NSGA-III FoM > Fixed 8     : %d scenarios\n', sum(dFoM_NSGA_F8(rs) > 0));
fprintf('NSGA-III JFI > best homog. : %d scenarios\n', sum(dJFI_NSGA(rs) > 0));
fprintf('NSGA-III median tput > best homog.: %d scenarios\n', sum(dMed_NSGA(rs) > 0));
fprintf('NSGA-III avg tput > best homog.   : %d scenarios\n', sum(dTput_NSGA(rs) > 0));
fprintf('Mean rank NSGA-III %.2f | MOWOA %.2f | Fixed 10 %.2f | Fixed 15 %.2f | Fixed 8 %.2f\n', ...
    mean(RankAll(rs,idxNSGA)), mean(RankAll(rs,idxMOWOA)), mean(RankAll(rs,fixedList==10)), ...
    mean(RankAll(rs,fixedList==15)), mean(RankAll(rs,idxFix8)));
tops = bestName(rs);
[u, ~, ju] = unique(tops);
cnt = accumarray(ju, 1);
fprintf('Top configuration frequency over perturbed scenarios:\n');
for i = 1:numel(u)
    fprintf('   %-24s %d\n', u{i}, cnt(i));
end
fprintf('Scenarios where NSGA-III is NOT rank 1:\n');
for s = rs
    if RankAll(s,idxNSGA) ~= 1
        fprintf('   #%2d %-12s %-28s rank %d (top: %s)\n', s, scen{s}{1}, scen{s}{2}, RankAll(s,idxNSGA), bestName{s});
    end
end

% ---- exports
write_cell_word(summaryHdr, summaryRows, fullfile(outDir, 'Table_R2P4_Sensitivity_Summary.doc'), ...
    'Sensitivity analysis (Layer 1): rank and margin of NSGA-III and MOWOA per scenario');
write_cell_word(fomHdr, fomRows, fullfile(outDir, 'Table_R2P4_FoM_All_Scenarios.doc'), ...
    'Pooled equal-weight FoM of all 13 configurations per scenario');
write_cell_word([{'ID','Scenario'}, cfgNames], rankRows, fullfile(outDir, 'Table_R2P4_Rank_All_Scenarios.doc'), ...
    'FoM rank of all 13 configurations per scenario');

detRows = cell(nS*nC, 11);
r = 0;
for s = 1:nS
    for c = 1:nC
        r = r + 1;
        detRows(r,:) = {s, scen{s}{2}, cfgNames{c}, rnd(MetricsAll(s,c,1), 4), rnd(MetricsAll(s,c,2), 4), ...
            rnd(MetricsAll(s,c,3), 4), rnd(MetricsAll(s,c,4), 4), rnd(MetricsAll(s,c,5), 4), ...
            rnd(MedianTput(s,c), 4), rnd(FoMAll(s,c), 4), RankAll(s,c)};
    end
end
write_cell_word({'ID','Scenario','Configuration','Avg Tput','5%-tile SINR','JFI','Overhead %','Interference dBm', ...
    'Median Tput','FoM','Rank'}, detRows, fullfile(outDir, 'Table_R2P4_Detailed_Metrics.doc'), ...
    'Detailed metrics of all configurations in all scenarios');

try
    fig = figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 1100 700]);
    subplot(2,1,1);
    hold on;
    plot(1:nS, RankAll(:,idxNSGA), 'o-', 'LineWidth', 1.4, 'DisplayName', 'NSGA-III');
    plot(1:nS, RankAll(:,idxMOWOA), 's-', 'LineWidth', 1.4, 'DisplayName', 'MOWOA');
    plot(1:nS, RankAll(:,fixedList==10), '^--', 'LineWidth', 1.0, 'DisplayName', 'Fixed 10');
    plot(1:nS, RankAll(:,fixedList==15), 'v--', 'LineWidth', 1.0, 'DisplayName', 'Fixed 15');
    plot(1:nS, RankAll(:,idxFix8), 'd--', 'LineWidth', 1.0, 'DisplayName', 'Fixed 8');
    set(gca, 'YDir', 'reverse'); ylim([0.5 nC+0.5]); xlim([0.5 nS+0.5]);
    xlabel('Scenario ID (see Table)'); ylabel('Pooled FoM rank (1 = best)');
    title('Rank of selected configurations across sensitivity scenarios'); grid on; legend('Location','eastoutside');
    subplot(2,1,2);
    bar(1:nS, [dFoM_NSGA, dFoM_MOW]);
    xlabel('Scenario ID (see Table)'); ylabel('\DeltaFoM vs best homogeneous');
    legend({'NSGA-III','MOWOA'}, 'Location', 'eastoutside'); grid on;
    title('Pooled-FoM margin over the best homogeneous configuration (positive = better)');
    save_png_compat(fig, fullfile(outDir, 'Fig_R2P4_Sensitivity_Ranks.png'));
    close(fig);
catch ME
    warning('Figure export skipped: %s', ME.message);
end

RES = struct();
RES.scenarios = scen; RES.cfgNames = cfgNames; RES.cfgK = cfgK;
RES.Metrics = MetricsAll; RES.MedianTput = MedianTput; RES.FoM = FoMAll; RES.Rank = RankAll;
RES.dFoM_NSGA = dFoM_NSGA; RES.dFoM_MOWOA = dFoM_MOW; RES.dTput_NSGA = dTput_NSGA; RES.dJFI_NSGA = dJFI_NSGA;
RES.bestName = bestName; RES.bestHomName = bestHomName;
RES.summaryHdr = summaryHdr; RES.summaryRows = summaryRows;
try
    save(fullfile(outDir, 'R2P4_Layer1_results.mat'), 'RES', '-v7');
catch
end
fprintf('\nDone in %.0f s. Outputs saved in: %s\n', toc(tAll), outDir);
end

% =========================================================================
% Parameter definitions (identical to the main script)
% =========================================================================
function P = nominal_params()
P.numBS = 7;
P.numSec = 3;
P.numPairs = P.numBS * P.numSec;
P.UEsPerSec = 20;
P.useNonUniformLoad = true;
P.minUEsPerSec = 8;
P.maxUEsPerSec = 35;
P.loadJitterUE = 3;
P.sectorLoadProfile = [34 20 10, 14 28 12, 22 9 32, 11 24 18, 30 13 21, 16 27 8, 25 15 29];
P.NsnapOpt = 25;
P.NsnapEval = 200;
P.BW_Hz = 100e6;
P.f_c_Hz = 28e9;
P.Pt_dBm = 33;
P.NF_dB = 9;
P.antennaGain_dBi = 15;
P.frontBackLimit_dB = 30;
P.sectorSpan_deg = 120;
P.sectorRadius_m = 150;
P.mu = 3;
P.nSym_slot = 14;
P.nSym_SSB = 4;
P.T_ssb_period_ms = 20;
P.T_csi_period_ms = 5;
P.OH_cap = 0.50;
P.beamComplexityPenaltyMax = 0.10;
P.beamComplexityPenaltyPower = 1.0;
P.rho_active = 0.70;
P.rho_idle = 0.05;
P.Nref = 30;
P.eta_overlap = 0.50;
P.pCorrectAt8 = 0.90;
P.pCorrectSlope = 0.012;
P.pCorrectMin = 0.65;
P.pCorrectMax = 0.96;
P.sigmaSh_dB = 4;
P.coverageThreshold_dB = 3.0;
P.bsPos = [500 500; 800 500; 200 500; 650 760; 650 240; 350 760; 350 240];
P.beamCandidates = [2 3 4 6 8 10 15 20 24];
P.numCandidates = numel(P.beamCandidates);
P.seedEvalData = 51001;
P = finalize_params(P);
end

function P = finalize_params(P)
% Recompute every derived quantity after any parameter change.
P.Pt_W = 10^((P.Pt_dBm - 30)/10);
P.noise_dBm = -174 + 10*log10(P.BW_Hz) + P.NF_dB;
P.noise_W = 10^((P.noise_dBm - 30)/10);
P.T_slot_ms = 1/(2^P.mu);
P.Tsym_ms = P.T_slot_ms/P.nSym_slot;
P.T_SSB_ms = P.nSym_SSB*P.Tsym_ms;
P.OH_CSI_reference = P.Tsym_ms/P.T_csi_period_ms;
end

function P = apply_scenario(P0, args)
% args: {'field', value, 'field', value, ...}; 'loadScale' scales the load profile.
P = P0;
for i = 1:2:numel(args)
    key = args{i}; val = args{i+1};
    if strcmp(key, 'loadScale')
        P.sectorLoadProfile = round(P0.sectorLoadProfile * val);
        P.minUEsPerSec = max(1, round(P0.minUEsPerSec * val));
        P.maxUEsPerSec = max(P.minUEsPerSec, round(P0.maxUEsPerSec * val));
    else
        P.(key) = val;
    end
end
P = finalize_params(P);
end

function scen = define_scenarios()
% {group, label, {parameter, value, ...}}
scen = {
 {'Nominal',   'Nominal parameters',            {}}
 {'Beam error','pCorrectAt8 = 0.80',            {'pCorrectAt8', 0.80}}
 {'Beam error','pCorrectAt8 = 0.85',            {'pCorrectAt8', 0.85}}
 {'Beam error','pCorrectAt8 = 0.95',            {'pCorrectAt8', 0.95}}
 {'Beam error','pCorrectSlope = 0',             {'pCorrectSlope', 0}}
 {'Beam error','pCorrectSlope = 0.006',         {'pCorrectSlope', 0.006}}
 {'Beam error','pCorrectSlope = 0.024',         {'pCorrectSlope', 0.024}}
 {'Overhead',  'CSI period 2.5 ms',             {'T_csi_period_ms', 2.5}}
 {'Overhead',  'CSI period 10 ms',              {'T_csi_period_ms', 10}}
 {'Overhead',  'SSB period 10 ms',              {'T_ssb_period_ms', 10}}
 {'Overhead',  'SSB period 40 ms',              {'T_ssb_period_ms', 40}}
 {'Overhead',  'Complexity penalty 0',          {'beamComplexityPenaltyMax', 0}}
 {'Overhead',  'Complexity penalty 0.05',       {'beamComplexityPenaltyMax', 0.05}}
 {'Overhead',  'Complexity penalty 0.20',       {'beamComplexityPenaltyMax', 0.20}}
 {'Traffic',   'rho_active = 0.50',             {'rho_active', 0.50}}
 {'Traffic',   'rho_active = 0.90',             {'rho_active', 0.90}}
 {'Traffic',   'rho_idle = 0.02',               {'rho_idle', 0.02}}
 {'Traffic',   'rho_idle = 0.10',               {'rho_idle', 0.10}}
 {'Traffic',   'eta_overlap = 0.30',            {'eta_overlap', 0.30}}
 {'Traffic',   'eta_overlap = 0.70',            {'eta_overlap', 0.70}}
 {'Traffic',   'Load profile x0.5',             {'loadScale', 0.5}}
 {'Traffic',   'Load profile x1.5',             {'loadScale', 1.5}}
 {'Propagation','Shadowing sigma = 2 dB',       {'sigmaSh_dB', 2}}
 {'Propagation','Shadowing sigma = 6 dB',       {'sigmaSh_dB', 6}}
 {'Propagation','Shadowing sigma = 8 dB',       {'sigmaSh_dB', 8}}
 {'Propagation','Carrier 39 GHz',               {'f_c_Hz', 39e9}}
 {'Propagation','Tx power 30 dBm',              {'Pt_dBm', 30}}
 {'Propagation','Tx power 36 dBm',              {'Pt_dBm', 36}}
 {'Combined',  'Harsh (p8 0.80, slope 0.024, sigma 8 dB, rho_act 0.90, penalty 0.20)', ...
               {'pCorrectAt8', 0.80, 'pCorrectSlope', 0.024, 'sigmaSh_dB', 8, 'rho_active', 0.90, 'beamComplexityPenaltyMax', 0.20}}
 {'Combined',  'Benign (p8 0.95, slope 0.006, sigma 2 dB, rho_act 0.50, penalty 0.05)', ...
               {'pCorrectAt8', 0.95, 'pCorrectSlope', 0.006, 'sigmaSh_dB', 2, 'rho_active', 0.50, 'beamComplexityPenaltyMax', 0.05}}
};
end

function write_cell_word(hdr, rows, fname, tableTitle)
% Export a header cell array and a cell matrix of rows to a Word-readable .doc (HTML).
fid = fopen(fname, 'w');
if fid == -1
    warning('write_cell_word: cannot open %s', fname);
    return;
end
fprintf(fid, '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">\n');
fprintf(fid, '<head><meta charset="UTF-8"><title>%s</title>\n', tableTitle);
fprintf(fid, ['<style> body{font-family:Calibri,Arial,sans-serif;} table{border-collapse:collapse;width:100%%;} ' ...
    'th,td{border:1px solid #444444;padding:4px 6px;text-align:center;font-size:9pt;} ' ...
    'th{background-color:#D9E1F2;font-weight:bold;} h1{font-size:14pt;color:#1F4E78;} </style>\n']);
fprintf(fid, '</head><body>\n<h1>%s</h1>\n<table>\n<tr>', tableTitle);
for c = 1:numel(hdr)
    fprintf(fid, '<th>%s</th>', hdr{c});
end
fprintf(fid, '</tr>\n');
for r = 1:size(rows,1)
    fprintf(fid, '<tr>');
    for c = 1:size(rows,2)
        v = rows{r,c};
        if ischar(v)
            s = v;
        elseif isnumeric(v) && isscalar(v)
            if v == round(v), s = sprintf('%d', v); else s = sprintf('%.4f', v); end
        else
            s = '';
        end
        fprintf(fid, '<td>%s</td>', s);
    end
    fprintf(fid, '</tr>\n');
end
fprintf(fid, '</table>\n</body></html>');
fclose(fid);
end

% =========================================================================
% Model functions copied unchanged from nsga3_mowoa_beam_archive_R2P2.m
% =========================================================================

function y = rnd(x, d)
% Portable rounding to d decimals (also works in Octave).
y = round(x * 10^d) / 10^d;
end

function DATA = generate_mc_data(P, Nsnap, seedValue)
rng(seedValue, 'twister');
DATA = repmat(struct(), Nsnap, 1);

for snap = 1:Nsnap
    sectorLoad = generate_sector_loads(P);
    N = sum(sectorLoad);
    user = zeros(N, 5); % bs, sector, pair, x, y
    row = 0;

    % UEs are generated inside each active sector. In the corrected version,
    % sector loads are intentionally non-uniform to avoid artificial network
    % symmetry and to make sector-dependent beam selection meaningful.
    for bs = 1:P.numBS
        sx = P.bsPos(bs,1);
        sy = P.bsPos(bs,2);
        for sec = 1:P.numSec
            pair = (bs-1)*P.numSec + sec;
            Nu = sectorLoad(pair);
            az0 = (sec-1) * P.sectorSpan_deg;
            az1 = sec * P.sectorSpan_deg;
            r = sqrt(rand(Nu,1)) * P.sectorRadius_m;
            az = az0 + rand(Nu,1) * (az1 - az0);
            x = sx + r .* cosd(az);
            y = sy + r .* sind(az);
            idx = row + (1:Nu);
            user(idx,:) = [bs*ones(Nu,1), sec*ones(Nu,1), ...
                           pair*ones(Nu,1), x, y];
            row = row + Nu;
        end
    end

    x = user(:,4);
    y = user(:,5);

    localAng = zeros(N, P.numPairs);
    PL_dB = zeros(N, P.numPairs);

    for q = 1:P.numPairs
        [bsq, secq] = pair_to_bssec(q, P);
        xb = P.bsPos(bsq,1);
        yb = P.bsPos(bsq,2);
        th = atan2d(y - yb, x - xb);
        th(th < 0) = th(th < 0) + 360;

        % Corrected interference-angle model:
        % Do NOT clamp out-of-sector directions to 120-eps. Instead, keep
        % the wrapped local angle in [0,360). The antenna pattern then uses
        % wrap180(localAngle - beamCenter), which naturally gives low gain
        % for users outside the sector main angular region.
        thLocal = th - (secq-1)*P.sectorSpan_deg;
        thLocal = mod(thLocal, 360);
        localAng(:,q) = thLocal;

        d = hypot(x - xb, y - yb);
        PL_dB(:,q) = path_loss_uma_simple(d, P.f_c_Hz) + P.sigmaSh_dB*randn(N,1);
    end

    rhoSector = P.rho_idle + (P.rho_active - P.rho_idle) .* min(1, sectorLoad(:)/P.Nref);

    DATA(snap).snapshot = snap;
    DATA(snap).sectorLoad = sectorLoad(:);
    DATA(snap).rhoSector = rhoSector(:);
    DATA(snap).bsIdx = user(:,1);
    DATA(snap).secIdx = user(:,2);
    DATA(snap).pairIdx = user(:,3);
    DATA(snap).x_m = x;
    DATA(snap).y_m = y;
    DATA(snap).localAng = localAng;
    DATA(snap).PL_dB = PL_dB;
    DATA(snap).randCorrect = rand(N,1);
    DATA(snap).randNeighbor = rand(N,1);
    DATA(snap).randInterfBeam = rand(N, P.numPairs);
end
end

function [metrics, rows] = evaluate_solution(Kvec, P, DATA, returnRows)
if nargin < 4
    returnRows = false;
end

Kvec = Kvec(:)';
Nsnap = numel(DATA);
Ntot = 0;
for ss = 1:Nsnap
    Ntot = Ntot + numel(DATA(ss).pairIdx);
end

allSinr_dB = zeros(Ntot,1);
allTput = zeros(Ntot,1);
allInterf_W = zeros(Ntot,1);
allOH = zeros(Ntot,1);

if returnRows
    allSnap = zeros(Ntot,1);
    allBS = zeros(Ntot,1);
    allSec = zeros(Ntot,1);
    allPair = zeros(Ntot,1);
    allK = zeros(Ntot,1);
    allLoad = zeros(Ntot,1);
    allPcorrect = zeros(Ntot,1);
    allX = zeros(Ntot,1);
    allY = zeros(Ntot,1);
end

sectorOH = compute_sector_overheads(Kvec, P);
ptr = 0;

for ss = 1:Nsnap
    D = DATA(ss);
    N = numel(D.pairIdx);
    pairIdx = D.pairIdx(:);
    rowIdx = (1:N)';

    Kserv = Kvec(pairIdx);
    Kserv = Kserv(:);
    HPBWserv = P.sectorSpan_deg ./ Kserv;

    indServ = sub2ind([N P.numPairs], rowIdx, pairIdx);
    thServ = D.localAng(indServ);

    % Serving users are generated inside their serving sector, but we still
    % clamp numerically to [0,120) for robust beam-index calculation.
    thServForIndex = thServ;
    thServForIndex(thServForIndex < 0) = 0;
    thServForIndex(thServForIndex >= P.sectorSpan_deg) = P.sectorSpan_deg - eps;

    PLserv = D.PL_dB(indServ);

    % Uniform sector codebook: center angles are (0.5:1:K-0.5)*HPBW.
    bestBeamIdx = floor(thServForIndex ./ HPBWserv) + 1;
    bestBeamIdx = max(bestBeamIdx, 1);
    bestBeamIdx = min(bestBeamIdx, Kserv);

    chosenBeamIdx = bestBeamIdx;

    % Corrected beam-selection model: p_correct is K-dependent. Narrower beams
    % are more sensitive to angular error and therefore have a lower chance of
    % selecting the exact best beam.
    pCorrectUser = beam_correct_probability(Kserv, P);
    miss = D.randCorrect(:) > pCorrectUser;
    if any(miss)
        onlyLeft = miss & (bestBeamIdx == Kserv) & (Kserv > 1);
        onlyRight = miss & (bestBeamIdx == 1) & (Kserv > 1);
        middle = miss & (bestBeamIdx > 1) & (bestBeamIdx < Kserv);

        chosenBeamIdx(onlyLeft) = bestBeamIdx(onlyLeft) - 1;
        chosenBeamIdx(onlyRight) = bestBeamIdx(onlyRight) + 1;

        midIdx = find(middle);
        if ~isempty(midIdx)
            chosenBeamIdx(midIdx) = bestBeamIdx(midIdx) - 1;
            chooseRight = D.randNeighbor(midIdx) >= 0.5;
            chosenBeamIdx(midIdx(chooseRight)) = bestBeamIdx(midIdx(chooseRight)) + 1;
        end
    end

    beamCenterServ = (chosenBeamIdx - 0.5) .* HPBWserv;
    deltaServ = abs(wrap180_local(thServ - beamCenterServ));
    Gserv = beam_gain(deltaServ, HPBWserv, P.antennaGain_dBi, P.frontBackLimit_dB);
    g_eff = 10.^((Gserv - PLserv)/10);

    % Load-aware inter-sector interference from all non-serving sectors.
    % Each interfering sector has its own rho based on its current snapshot load.
    I_W = zeros(N,1);
    for q = 1:P.numPairs
        active = pairIdx ~= q;
        if ~any(active)
            continue;
        end
        Kq = Kvec(q);
        HPBWq = P.sectorSpan_deg / Kq;
        intBeamIdx = floor(D.randInterfBeam(:,q) * Kq) + 1;
        intBeamIdx = max(intBeamIdx, 1);
        intBeamIdx = min(intBeamIdx, Kq);
        beamCenterI = (intBeamIdx - 0.5) * HPBWq;

        % Corrected: localAng can be outside [0,120). The wrapped angular
        % distance to the selected interfering beam center is used directly.
        deltaI = abs(wrap180_local(D.localAng(:,q) - beamCenterI));
        GI = beam_gain(deltaI, HPBWq, P.antennaGain_dBi, P.frontBackLimit_dB);
        Iterm = P.eta_overlap * D.rhoSector(q) * 10.^((P.Pt_dBm + GI - D.PL_dB(:,q) - 30)/10);
        I_W(active) = I_W(active) + Iterm(active);
    end

    sinrLinear = P.Pt_W * g_eff ./ (P.noise_W + I_W);
    sinr_dB = 10*log10(max(sinrLinear, realmin));
    OHuser = sectorOH(pairIdx);

    % No WF: equal resource share among the users currently assigned to the
    % same sector. With non-uniform load, bandwidth share is sector-dependent.
    loadUser = D.sectorLoad(pairIdx);
    loadUser = max(loadUser(:), 1);
    tput = (P.BW_Hz ./ loadUser) .* log2(1 + sinrLinear) / 1e6 .* (1 - OHuser);

    idxOut = ptr + (1:N);
    allSinr_dB(idxOut) = sinr_dB;
    allTput(idxOut) = tput;
    allInterf_W(idxOut) = I_W;
    allOH(idxOut) = OHuser;

    if returnRows
        allSnap(idxOut) = ss;
        allBS(idxOut) = D.bsIdx;
        allSec(idxOut) = D.secIdx;
        allPair(idxOut) = pairIdx;
        allK(idxOut) = Kserv;
        allLoad(idxOut) = loadUser;
        allPcorrect(idxOut) = pCorrectUser;
        allX(idxOut) = D.x_m;
        allY(idxOut) = D.y_m;
    end

    ptr = ptr + N;
end

metrics = struct();
metrics.AvgSINR_dB = mean(allSinr_dB);
metrics.P5SINR_dB = prctile(allSinr_dB, 5);
metrics.Coverage_pct = 100 * mean(allSinr_dB > P.coverageThreshold_dB);
metrics.AvgEffTput_Mbps = mean(allTput);
metrics.JFI = jain_fairness(allTput);
metrics.AvgOverhead = mean(allOH);
metrics.AvgOverhead_percent = 100 * metrics.AvgOverhead;
metrics.AvgInterference_W = mean(allInterf_W);
metrics.AvgInterference_dBm = 10*log10(max(metrics.AvgInterference_W, realmin)*1000);
metrics.P5Tput_Mbps = prctile(allTput, 5);
metrics.MedianTput_Mbps = median(allTput);

if returnRows
    interf_dBm = 10*log10(max(allInterf_W, realmin)*1000);
    rows = table(allSnap, allBS, allSec, allPair, allK, allLoad, allPcorrect, allX, allY, ...
        allSinr_dB, allTput, allOH, 100*allOH, allInterf_W, interf_dBm, ...
        'VariableNames', {'snapshot','bs','sector','pair','numBeams','sectorLoad','pCorrectBeam','x_m','y_m', ...
        'sinr_dB','tput_Mbps','overhead','overhead_percent','interference_W','interference_dBm'});
else
    rows = [];
end
end

function Kvec = heuristic_beam_vector(P, mode)
% HEURISTIC_BEAM_VECTOR  Simple closed-form, load-aware beam-count rule (no optimization).
% The NOMINAL sector load profile is linearly mapped onto [Kmin, Kmax] and
% snapped to the nearest candidate beam count.
%   'proportional': higher load -> more beams.
%   'inverse'     : higher load -> fewer beams.
nom = P.sectorLoadProfile(:)';
lo = min(nom); hi = max(nom);
Kmin = min(P.beamCandidates); Kmax = max(P.beamCandidates);
t = (nom - lo) / (hi - lo);
if strcmp(mode, 'inverse')
    t = 1 - t;
end
target = Kmin + t * (Kmax - Kmin);
Kvec = zeros(1, numel(target));
for q = 1:numel(target)
    [~, j] = min(abs(P.beamCandidates - target(q)));
    Kvec(q) = P.beamCandidates(j);
end
end

function sectorOH = compute_sector_overheads(Kvec, P)
Kvec = Kvec(:)';

% Corrected overhead model:
% 1) SSB sweeping overhead grows with K.
% 2) CSI/beam refinement overhead also grows with K, instead of being fixed.
% 3) A normalized beam-management complexity penalty is included to represent
%    search latency, measurement/reporting burden, and control complexity.
OH_SSB = Kvec * P.T_SSB_ms / P.T_ssb_period_ms;
OH_CSI = Kvec * P.Tsym_ms / P.T_csi_period_ms;

Kmin = min(P.beamCandidates);
Kmax = max(P.beamCandidates);
if Kmax > Kmin
    Knorm = (Kvec - Kmin) / (Kmax - Kmin);
else
    Knorm = zeros(size(Kvec));
end
OH_complexity = P.beamComplexityPenaltyMax * (Knorm .^ P.beamComplexityPenaltyPower);

sectorOH = min(OH_SSB + OH_CSI + OH_complexity, P.OH_cap);
sectorOH = sectorOH(:);
end

function [FoM, normMetrics] = compute_fom_equal_weights(metrics)
% metrics columns:
% 1 AvgEffTput_Mbps        benefit
% 2 P5SINR_dB              benefit
% 3 JFI                    benefit
% 4 AvgOverhead_percent    cost
% 5 AvgInterference_dBm    cost
% 6 Coverage_pct           reporting only
% 7 AvgSINR_dB             reporting only
% 8 P5Tput_Mbps            reporting only

X = metrics(:,1:5);
benefit = [true true true false false];
normMetrics = zeros(size(X));

for j = 1:5
    x = X(:,j);
    xmin = min(x);
    xmax = max(x);
    if abs(xmax - xmin) < 1e-12
        normMetrics(:,j) = ones(size(x));
    else
        if benefit(j)
            normMetrics(:,j) = (x - xmin) / (xmax - xmin);
        else
            normMetrics(:,j) = (xmax - x) / (xmax - xmin);
        end
    end
end

weights = ones(1,5)/5;
FoM = normMetrics * weights(:);
end

function loadVec = generate_sector_loads(P)
if isfield(P, 'useNonUniformLoad') && P.useNonUniformLoad
    loadVec = P.sectorLoadProfile(:);
    jitter = round((2*rand(P.numPairs,1) - 1) * P.loadJitterUE);
    loadVec = loadVec + jitter;
    loadVec = max(P.minUEsPerSec, min(P.maxUEsPerSec, loadVec));
else
    loadVec = P.UEsPerSec * ones(P.numPairs,1);
end
loadVec = round(loadVec(:));
end

function [bs, sec] = pair_to_bssec(pair, P)
bs = floor((pair-1)/P.numSec) + 1;
sec = mod(pair-1, P.numSec) + 1;
end

function pCorr = beam_correct_probability(K, P)
% K-dependent beam-selection probability. The reference is pCorrectAt8 at
% K=8. Larger K means narrower beams and a higher probability of beam-index
% error; smaller K means wider beams and a more robust selection.
pCorr = P.pCorrectAt8 - P.pCorrectSlope * (K - 8);
pCorr = max(P.pCorrectMin, min(P.pCorrectMax, pCorr));
end

function PLdB = path_loss_uma_simple(d_m, f_Hz)
% Close, simple UMa-like path-loss expression retained from the original code.
% If your manuscript states the full 3GPP TR 38.901 UMa LOS/NLOS model,
% replace this function with the exact TR 38.901 implementation.
f_GHz = f_Hz/1e9;
d_m = max(d_m, 1);
PLdB = 32.4 + 21*log10(d_m) + 20*log10(f_GHz);
end

function G = beam_gain(delta, HPBW, Gmax, Am)
G = Gmax - min(12*(delta./HPBW).^2, Am);
end

function ang = wrap180_local(ang)
ang = mod(ang + 180, 360) - 180;
end

function J = jain_fairness(x)
x = x(:);
x(~isfinite(x)) = 0;
den = numel(x)*sum(x.^2);
if den <= 0
    J = 0;
else
    J = (sum(x)^2)/den;
end
end

function save_png_compat(figHandle, fname)
set(figHandle, 'PaperPositionMode', 'auto');
print(figHandle, fname, '-dpng', '-r300');
end

% =========================================================================
% Utility functions
