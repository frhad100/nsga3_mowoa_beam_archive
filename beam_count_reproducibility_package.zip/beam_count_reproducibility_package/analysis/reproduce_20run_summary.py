#!/usr/bin/env python3
"""
reproduce_20run_summary.py
Recomputes, from the CSV files in ../data, the 20-run summary values that are reported in
Tables 3 and 4 and in the robustness analysis of Section 7.E of the manuscript:
  * pooled equal-weight FoM of the 13 candidates in every run (checked against the stored values),
  * mean +/- SD over the 20 runs of the metrics of the FoM-selected NSGA-III and MOWOA solutions,
  * mean pooled FoM, SD, mean rank and number of first places of every candidate,
  * mean number of beams, correlation between beam count and nominal sector load,
  * ranking after excluding candidates, and
  * share of random weight vectors (symmetric Dirichlet) for which each candidate has the highest FoM.
The hypothesis tests, bootstrap confidence intervals and Pareto-front indicators of Tables 8-12
(Section 7.H) are produced by code/multiseed_R2P3.m.

Usage:   python3 reproduce_20run_summary.py            (needs only Python 3 and NumPy)
"""
import csv, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', 'data')
NRUNS = 20
BENEFIT = np.array([1, 1, 1, 0, 0], bool)       # tput, P5 SINR, JFI | overhead, interference
M5 = ['avg_effective_throughput_Mbps', 'p5_SINR_dB', 'jain_fairness_index', 'overhead_percent', 'interference_dBm']
SECTORS = ['BS%d_Sec%d' % (b, s) for b in range(1, 8) for s in range(1, 4)]

def read(name):
    with open(os.path.join(DATA, name), newline='') as f:
        return list(csv.DictReader(f))

def norm_scores(X):
    lo, hi = X.min(0), X.max(0)
    return np.where(BENEFIT, (X - lo) / (hi - lo), (hi - X) / (hi - lo))

def pool_fom(X):
    return norm_scores(X) @ (np.ones(5) / 5)

# ---------------------------------------------------------------- load the data
met = read('evaluation_metrics_selected.csv')
det = [r for r in met if r['run'] == 'all']                       # 11 deterministic configurations
det_names = [r['method'] for r in det]
def mrow(r, keys): return [float(r[k]) for k in keys]
MET_ALL = ['avg_effective_throughput_Mbps', 'p5_SINR_dB', 'jain_fairness_index', 'overhead_percent', 'interference_dBm',
           'coverage_percent', 'avg_SINR_dB', 'p5_throughput_Mbps', 'median_throughput_Mbps']
sel = {m: np.array([mrow(r, MET_ALL) for r in met if r['method'] == m]) for m in ('NSGA-III', 'MOWOA')}   # 20 x 9
assert all(v.shape[0] == NRUNS for v in sel.values())
detM = np.array([mrow(r, MET_ALL) for r in det])                  # 11 x 9
cand = det_names + ['NSGA-III', 'MOWOA']

stored = {}
for r in read('pooled_fom_and_ranks.csv'):
    if r['FoM_pool13'] != '':
        stored.setdefault(int(r['run']), {})[r['candidate']] = (float(r['FoM_pool13']), int(r['rank_pool13']))

F = np.zeros((NRUNS, 13)); RK = np.zeros((NRUNS, 13), int)
for i in range(NRUNS):
    X = np.vstack([detM[:, :5], sel['NSGA-III'][i, :5], sel['MOWOA'][i, :5]])
    F[i] = pool_fom(X)
    RK[i] = np.argsort(np.argsort(-F[i])) + 1
    for j, c in enumerate(cand):
        sf, sr = stored[i + 1][c]
        assert abs(sf - F[i, j]) < 1e-9 and sr == RK[i, j], ('mismatch', i + 1, c)
print('Check passed: pooled FoM and ranks recomputed from the metric values equal the stored ones (20 runs x 13 candidates).\n')

ms = lambda v: '%.4f +/- %.4f' % (v.mean(), v.std(ddof=1))
# ---------------------------------------------------------------- Table 3 / 4 values
print('=== Metrics of the FoM-selected solutions, mean +/- SD over 20 runs (Table 3) ===')
for k, name in enumerate(MET_ALL):
    print('%-32s NSGA-III %s | MOWOA %s' % (name, ms(sel['NSGA-III'][:, k]), ms(sel['MOWOA'][:, k])))
print('\n=== Deterministic configurations (identical in every run) ===')
for j, n in enumerate(det_names):
    print('%-22s' % n, ' '.join('%s=%.4f' % (MET_ALL[k][:12], detM[j, k]) for k in range(5)))
print('\n=== Pooled FoM over 13 candidates (Table 4): mean, SD, mean rank, runs ranked first, runs in top three ===')
for j in np.argsort(-F.mean(0)):
    print('%-24s FoM %.4f +/- %.4f | mean rank %.2f | first in %2d | top3 in %2d' %
          (cand[j], F[:, j].mean(), F[:, j].std(ddof=1), RK[:, j].mean(), (RK[:, j] == 1).sum(), (RK[:, j] <= 3).sum()))

# ---------------------------------------------------------------- beam statistics
par = {r['name']: r['value'] for r in read('parameters.csv') if r['group'] == 'network_and_optimizer'}
load = np.array([float(x) for x in par['sectorLoadProfile'].split()])
Kmat = {m: np.array([[int(r[s]) for s in SECTORS] for r in read('selected_beam_vectors.csv') if r['method'] == m]) for m in ('NSGA-III', 'MOWOA')}
print('\n=== Beam counts (Section 7.A / 7.E) ===')
for m in Kmat:
    cr = np.array([np.corrcoef(k, load)[0, 1] for k in Kmat[m]])
    print('%-9s mean beams/sector %.2f +/- %.2f | corr(beams, nominal load) mean %.2f (min %.2f, max %.2f), negative in %d of 20 runs'
          % (m, Kmat[m].mean(1).mean(), Kmat[m].mean(1).std(ddof=1), cr.mean(), cr.min(), cr.max(), (cr < 0).sum()))
print('NSGA-III has the larger mean beam count in %d of 20 runs' % (Kmat['NSGA-III'].mean(1) > Kmat['MOWOA'].mean(1)).sum())

# ---------------------------------------------------------------- exclusion analysis
heur = ['Load-prop heuristic', 'Inverse-load heuristic']
print('\n=== Ranking after excluding candidates (Section 7.E) ===')
for lab, drop in [('without the two heuristics', heur), ('without heuristics and Fixed 2, 3, 4', heur + ['Fixed 2', 'Fixed 3', 'Fixed 4'])]:
    keep = [j for j, c in enumerate(cand) if c not in drop]
    first = 0; mow = []
    for i in range(NRUNS):
        X = np.vstack([detM[:, :5], sel['NSGA-III'][i, :5], sel['MOWOA'][i, :5]])[keep]
        names = [cand[keep[o]] for o in np.argsort(-pool_fom(X))]
        first += names[0] == 'NSGA-III'; mow.append(names.index('MOWOA') + 1)
    print('%-40s NSGA-III first in %2d of 20 runs; MOWOA rank distribution (1st, 2nd, 3rd, ...): %s'
          % (lab, first, np.bincount(mow, minlength=4)[1:4]))

# ---------------------------------------------------------------- random weights
rng = np.random.default_rng(12345)
shares = []; top3 = []
for i in range(NRUNS):
    X = np.vstack([detM[:, :5], sel['NSGA-III'][i, :5], sel['MOWOA'][i, :5]])
    W = rng.dirichlet(np.ones(5), 20000)
    Fw = W @ norm_scores(X).T          # 20000 x 13
    shares.append(np.bincount(Fw.argmax(1), minlength=13) / 20000)
    o = np.argsort(-Fw, 1)[:, :3]; top3.append(((o == 11) | (o == 12)).any(1).mean())
S = np.array(shares)
print('\n=== 20,000 random weight vectors per run (symmetric Dirichlet, seed 12345; Section 7.E) ===')
for j in np.argsort(-S.mean(0)):
    if S[:, j].mean() > 0.005:
        print('%-24s highest FoM in %4.1f%% of the draws on average (%.0f%% to %.0f%% between runs; reference run %.0f%%)'
              % (cand[j], 100 * S[:, j].mean(), 100 * S[:, j].min(), 100 * S[:, j].max(), 100 * S[0, j]))
print('NSGA-III or MOWOA among the three highest: %.0f%% on average (%.0f%% to %.0f%%)' % (100 * np.mean(top3), 100 * min(top3), 100 * max(top3)))
