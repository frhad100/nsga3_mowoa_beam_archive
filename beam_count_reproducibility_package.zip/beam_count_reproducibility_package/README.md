# Reproducibility package: Adaptive sector-wise beam-count optimization for 5G mmWave codebook beamforming (NSGA-III and MOWOA)

Companion package of the manuscript *"Adaptive Sector-Wise Beam-Count Optimization for 5G mmWave Codebook Beamforming: A Dual-Archive NSGA-III and MOWOA Study"* (IJIES, paper ID 20265654, Round 2).
It contains the implementation code, the exact random seeds, the snapshot-generation and optimization settings, the final Pareto archives, the selected beam vectors, and the scripts that produce the reported tables and figures.

Repository link: 

## 1. Contents

| Path | Content |
|---|---|
| `code/` | MATLAB implementation (six self-contained scripts and the wrapper `run_all.m`, see Section 3). |
| `data/seeds_per_run.csv` | All random seeds of the 20 runs (optimization data, initial population, NSGA-III, MOWOA, Q-learning A and B, evaluation data). |
| `data/parameters.csv` | Complete network, snapshot-generation, NSGA-III, MOWOA and Q-learning settings (values read directly from the saved setup of the runs). |
| `data/nsga3_reference_points.csv` | The 70 NSGA-III reference points (5 objectives, 4 divisions). |
| `data/selected_beam_vectors.csv` | Beam count of each of the 21 sectors for the FoM-selected NSGA-III and MOWOA solutions and the two Q-learning policies in every run, and for the 11 deterministic configurations (nine homogeneous beam counts, two load-aware heuristics). |
| `data/archives/nsga3_historical_archive_all_runs.csv`, `data/archives/mowoa_historical_archive_all_runs.csv` | Final historical Pareto archives of every run: beam counts of the 21 sectors, the five optimized objectives and eight metrics (evaluated on the 25-snapshot optimization data). The column `selected_by_FoM` marks the solution chosen by the equal-weight FoM. |
| `data/evaluation_metrics_selected.csv` | Nine metrics of every selected solution on the common 200-snapshot evaluation data. |
| `data/pooled_fom_and_ranks.csv` | Pooled equal-weight FoM and rank of every candidate in every run (pool of 13 and pool of 15 candidates). |
| `data/pareto_indicators.csv` | Archive size, hypervolume, IGD+ and additive epsilon indicator of both optimizers in every run. |
| `data/qlearning_training_trace_run001.csv` | Reward trace of the two Q-learning variants in the reference run (Fig. 5). |
| `data/Fig6_boxplots_20runs.png` | Fig. 6 of the manuscript. |
| `analysis/reproduce_20run_summary.py` | Recomputes the 20-run summary values of Tables 3 and 4 and of the robustness analysis of Section 7.E from the CSV files (Python 3 and NumPy only). |
| `analysis/expected_output.txt` | Output of this script. |

Conventions. Sectors are numbered `BSb_Secs` (base station b = 1..7, sector s = 1..3); sector index = 3(b-1)+s. Candidate beam counts are 2, 3, 4, 6, 8, 10, 15, 20 and 24. In the archive files, objectives 1-3 are stored with a negative sign (the optimizers minimize), objectives 4-5 are stored as they are. "Run 1" is the reference run of the manuscript (Figs. 1-5 and Tables 5-7); run r uses the original seeds plus 17(r-1).

## 2. Settings

* Network: 7 base stations, 3 sectors each (21 decision variables), non-uniform load of 8-35 users per sector (profile in `parameters.csv`), 28 GHz, 100 MHz, all remaining values in `data/parameters.csv`.
* Snapshot generation: `NsnapOpt` = 25 optimization snapshots (seed 41001 + 17(r-1)) and `NsnapEval` = 200 evaluation snapshots (seed 51001, the same for all runs and methods, so the 11 deterministic configurations are identical in every run).
* Optimizers: population 70, 100 generations/iterations (7,070 evaluations per method), crossover probability 0.9, mutation probability 2/21, working archive limit 70, unbounded historical archive; MOWOA spiral constant 1.
* Q-learning: 7,070 steps, discount factor 0.5, visit-count learning rate max(0.02, 1/n^0.6), epsilon-greedy exploration with geometric decay of epsilon from 1 to 0.02 over the first 70% of the steps; seeds 64001 + 17(r-1) (variant A) and +1 (variant B).
* The seed table is in `data/seeds_per_run.csv`; every script prints and stores the seeds it uses.

## 3. Scripts and the results they produce

| Script (in `code/`) | Produces |
|---|---|
| `nsga3_mowoa_beam_archive_R2P2.m` | Reference run of NSGA-III and MOWOA with the homogeneous and load-aware baselines: Figs. 1-4, the comparison of the fixed and optimized configurations (reference-run values underlying Tables 3-4), selected beam vectors and Pareto archives. |
| `rl_baseline_R2P1.m`, `plot_rl_curves_R2P1.m` | Q-learning baseline (Section 6.F): Table 7 and Fig. 5. |
| `sensitivity_layer1_R2P4.m` | Sensitivity analysis of the 27 perturbed scenarios without re-optimization: Table 5. |
| `nsga3_mowoa_beam_archive_R2P4_L2.m` | Re-optimization under the two beam-error scenarios (`pCorrectSlope` = 0 and 0.024): Table 6. |
| `multiseed_R2P3.m` | The 20 independent runs (NSGA-III, MOWOA and both Q-learning variants), pooled FoM of 15 candidates, hypervolume, IGD+, epsilon indicator, bootstrap confidence intervals, Wilcoxon tests with Holm correction, Vargha-Delaney A12 and the Friedman test: Tables 8-12 and Fig. 6. Run 1 reproduces the reference-run beam vectors and the script checks this automatically. |
| `analysis/reproduce_20run_summary.py` | Tables 3 and 4 (20-run means and standard deviations), and the beam-count, load-correlation, exclusion and random-weight results of Section 7.E. |
| `run_all.m` | Wrapper that calls the five steps above in the order of the manuscript (`run_all`, or `run_all(k)` for a single step). It does not modify any script. |

Mapping of the output tables of `multiseed_R2P3.m` to the manuscript: `Table_R2P3_1_Mean_CI` to Table 8, `Table_R2P3_3_NSGA3_vs_MOWOA` to Table 9, `Table_R2P3_4_Pareto_Indicators` to Table 10, `Table_R2P3_5_Versus_References` to Table 11, `Table_R2P3_7_Rank_Distribution` to Table 12; `Table_R2P3_6_Friedman` gives the Friedman test quoted in the text.

## 4. How to reproduce

Quick start: `run_all` runs steps 1-5 below in MATLAB and writes all outputs into the folder `results_run_all` of the current directory; `run_all(k)` or `run_all([3 4])` runs selected steps. Each step can also be run directly by calling the script named in it.

1. Reference run and Figs. 1-4: `nsga3_mowoa_beam_archive_R2P2` (output folder `nsga3_mowoa_beam_R2P2_outputs`).
2. Q-learning baseline, Table 7 and Fig. 5: `rl_baseline_R2P1`, then `plot_rl_curves_R2P1`.
3. Sensitivity analysis, Table 5: `sensitivity_layer1_R2P4`; it prints a warning if the nominal scenario does not reproduce Tables 3-4.
4. Re-optimization, Table 6: `nsga3_mowoa_beam_archive_R2P4_L2(0)`.
5. Twenty runs and statistics, Tables 8-12 and Fig. 6: `multiseed_R2P3(20)`. Each finished run is stored in `multiseed_R2P3_outputs/runs/run_XXX.mat`; an interrupted execution resumes from the finished runs, and `multiseed_R2P3('analyze')` repeats only the statistical analysis.

Tables 3 and 4 and Section 7.E (not a MATLAB step): `python3 analysis/reproduce_20run_summary.py` reads `data/*.csv`; its output must equal `analysis/expected_output.txt`.

Each script creates its output folder in the current directory. The CSV files in `data/` were exported from the saved results of `multiseed_R2P3.m`; `reproduce_20run_summary.py` verifies, for all 20 runs and 13 candidates, that the stored pooled FoM and ranks equal those recomputed from the metric values.

## 5. Notes

* The 20-run summary values of Tables 3 and 4 and of Section 7.E are computed by the Python script and not by MATLAB; all other numbers come from the MATLAB scripts.
* The archive files hold the historical archives (all non-dominated solutions found during a run, 701 for NSGA-III and 790 for MOWOA on average), evaluated on the optimization data; the selected solutions are evaluated on the separate evaluation data.
